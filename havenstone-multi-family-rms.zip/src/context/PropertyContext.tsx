import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Property, 
  Unit, 
  Prospect, 
  Lease, 
  WorkOrder, 
  MakeReadyTurn, 
  LedgerTransaction, 
  UserRole,
  ProspectStage,
  MaintenanceStatus,
  PackageDelivery,
  AmenityReservation
} from '../types/property';
import { 
  INITIAL_PROPERTIES, 
  INITIAL_UNITS, 
  INITIAL_PROSPECTS, 
  INITIAL_LEASES, 
  INITIAL_WORK_ORDERS, 
  INITIAL_TURNS, 
  INITIAL_LEDGER,
  INITIAL_PACKAGES,
  INITIAL_RESERVATIONS
} from '../data/mockData';

export interface NotificationItem {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  unread: boolean;
  category: 'leasing' | 'maintenance' | 'accounting' | 'system';
}

interface PropertyContextType {
  properties: Property[];
  units: Unit[];
  prospects: Prospect[];
  leases: Lease[];
  workOrders: WorkOrder[];
  turns: MakeReadyTurn[];
  ledger: LedgerTransaction[];
  packages: PackageDelivery[];
  reservations: AmenityReservation[];
  notifications: NotificationItem[];
  
  // View & Filtering State
  selectedPropertyId: string; // 'all' or specific property id
  setSelectedPropertyId: (id: string) => void;
  activeRole: UserRole;
  setActiveRole: (role: UserRole) => void;
  activeTab: 'dashboard' | 'leasing' | 'maintenance' | 'accounting' | 'units' | 'resident_portal';
  setActiveTab: (tab: 'dashboard' | 'leasing' | 'maintenance' | 'accounting' | 'units' | 'resident_portal') => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // Selected Property Helper
  currentProperty: Property | null;
  filteredUnits: Unit[];
  filteredLeases: Lease[];
  filteredProspects: Prospect[];
  filteredWorkOrders: WorkOrder[];
  filteredTurns: MakeReadyTurn[];
  filteredLedger: LedgerTransaction[];

  // Action Methods
  addWorkOrder: (order: Omit<WorkOrder, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateWorkOrderStatus: (id: string, status: MaintenanceStatus, notes?: string) => void;
  assignWorkOrderTech: (id: string, tech: string) => void;
  updateTurnStep: (turnId: string, stepIndex: number, completed: boolean) => void;
  
  advanceProspectStage: (prospectId: string, stage: ProspectStage) => void;
  convertProspectToLease: (prospectId: string, unitId: string, monthlyRent: number, securityDeposit: number) => void;
  
  sendRenewalOffer: (leaseId: string, proposedRent: number) => void;
  acceptRenewalOffer: (leaseId: string) => void;
  submitNoticeToVacate: (unitId: string, leaseId: string, moveOutDate: string) => void;

  postTransaction: (tx: Omit<LedgerTransaction, 'id' | 'referenceNo' | 'status'>) => void;
  
  // Resident Portal actions
  residentPayRent: (amount: number, method: 'ACH Direct' | 'Credit Card') => void;
  residentSubmitTicket: (category: any, title: string, description: string, entryPermission: boolean) => void;
  claimPackage: (packageId: string) => void;
  bookAmenity: (amenityName: string, date: string, timeSlot: string) => void;
  toggleAutopay: () => void;
  
  markNotificationRead: (id: string) => void;
  resetAllData: () => void;
}

const PropertyContext = createContext<PropertyContextType | undefined>(undefined);

const STORAGE_PREFIX = 'havenstone_mf_';

export const PropertyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [properties] = useState<Property[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}properties`);
    return saved ? JSON.parse(saved) : INITIAL_PROPERTIES;
  });

  const [units, setUnits] = useState<Unit[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}units`);
    return saved ? JSON.parse(saved) : INITIAL_UNITS;
  });

  const [prospects, setProspects] = useState<Prospect[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}prospects`);
    return saved ? JSON.parse(saved) : INITIAL_PROSPECTS;
  });

  const [leases, setLeases] = useState<Lease[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}leases`);
    return saved ? JSON.parse(saved) : INITIAL_LEASES;
  });

  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}work_orders`);
    return saved ? JSON.parse(saved) : INITIAL_WORK_ORDERS;
  });

  const [turns, setTurns] = useState<MakeReadyTurn[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}turns`);
    return saved ? JSON.parse(saved) : INITIAL_TURNS;
  });

  const [ledger, setLedger] = useState<LedgerTransaction[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}ledger`);
    return saved ? JSON.parse(saved) : INITIAL_LEDGER;
  });

  const [packages, setPackages] = useState<PackageDelivery[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}packages`);
    return saved ? JSON.parse(saved) : INITIAL_PACKAGES;
  });

  const [reservations, setReservations] = useState<AmenityReservation[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}reservations`);
    return saved ? JSON.parse(saved) : INITIAL_RESERVATIONS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif-1',
      title: 'Emergency Plumbing Ticket',
      description: 'Unit 101 - Water heater drip pan alert (Emergency SLA: 4h)',
      timestamp: '15m ago',
      unread: true,
      category: 'maintenance'
    },
    {
      id: 'notif-2',
      title: 'Application Approved',
      description: 'Danielle Brooks (Unit 302, Highland Park) ready for lease generation',
      timestamp: '1h ago',
      unread: true,
      category: 'leasing'
    },
    {
      id: 'notif-3',
      title: 'Delinquency Notice Sent',
      description: '3-Day Notice to Pay or Quit delivered for Unit 208 ($2,400 past due)',
      timestamp: '3h ago',
      unread: false,
      category: 'accounting'
    }
  ]);

  const [selectedPropertyId, setSelectedPropertyId] = useState<string>('prop-1');
  const [activeRole, setActiveRole] = useState<UserRole>('property_manager');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'leasing' | 'maintenance' | 'accounting' | 'units' | 'resident_portal'>('dashboard');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Persist state updates to local storage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}units`, JSON.stringify(units));
  }, [units]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}leases`, JSON.stringify(leases));
  }, [leases]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}prospects`, JSON.stringify(prospects));
  }, [prospects]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}work_orders`, JSON.stringify(workOrders));
  }, [workOrders]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}turns`, JSON.stringify(turns));
  }, [turns]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}ledger`, JSON.stringify(ledger));
  }, [ledger]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}packages`, JSON.stringify(packages));
  }, [packages]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_PREFIX}reservations`, JSON.stringify(reservations));
  }, [reservations]);

  // When switching to resident role, auto-navigate to resident_portal tab
  useEffect(() => {
    if (activeRole === 'resident_portal') {
      setActiveTab('resident_portal');
      setSelectedPropertyId('prop-1'); // Resident lives at Mercer Grand Unit 412
    } else if (activeTab === 'resident_portal') {
      setActiveTab('dashboard');
    }
  }, [activeRole]);

  // Current Property
  const currentProperty = selectedPropertyId === 'all' 
    ? null 
    : (properties.find(p => p.id === selectedPropertyId) || properties[0]);

  // Filtered collections
  const filterByProp = <T extends { propertyId?: string }>(items: T[]): T[] => {
    if (selectedPropertyId === 'all') return items;
    return items.filter(item => item.propertyId === selectedPropertyId);
  };

  const filteredUnits = filterByProp(units).filter(u => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return u.unitNumber.toLowerCase().includes(q) || 
           u.floorPlan.toLowerCase().includes(q) ||
           (u.currentResidentName && u.currentResidentName.toLowerCase().includes(q));
  });

  const filteredLeases = filterByProp(leases).filter(l => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return l.unitNumber.toLowerCase().includes(q) || 
           l.residentName.toLowerCase().includes(q) ||
           l.email.toLowerCase().includes(q);
  });

  const filteredProspects = filterByProp(prospects).filter(p => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return p.applicantName.toLowerCase().includes(q) || 
           p.email.toLowerCase().includes(q) ||
           p.desiredFloorPlan.toLowerCase().includes(q);
  });

  const filteredWorkOrders = filterByProp(workOrders).filter(w => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return w.id.toLowerCase().includes(q) || 
           w.unitNumber.toLowerCase().includes(q) || 
           w.title.toLowerCase().includes(q) ||
           w.residentName.toLowerCase().includes(q) ||
           w.assignedTech.toLowerCase().includes(q);
  });

  const filteredTurns = filterByProp(turns).filter(t => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return t.id.toLowerCase().includes(q) || 
           t.unitNumber.toLowerCase().includes(q) || 
           t.leadTech.toLowerCase().includes(q);
  });

  const filteredLedger = filterByProp(ledger).filter(l => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return l.id.toLowerCase().includes(q) || 
           l.unitNumber.toLowerCase().includes(q) || 
           l.residentName.toLowerCase().includes(q) ||
           l.referenceNo.toLowerCase().includes(q);
  });

  // Action implementations
  const addWorkOrder = (orderData: Omit<WorkOrder, 'id' | 'createdAt' | 'updatedAt'>) => {
    const id = `WO-${Math.floor(8900 + Math.random() * 1000)}`;
    const now = new Date();
    const formattedDate = `${now.toISOString().slice(0, 10)} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    
    const newOrder: WorkOrder = {
      ...orderData,
      id,
      createdAt: formattedDate,
      updatedAt: formattedDate,
      notes: [`${now.toISOString().slice(0, 10)}: Work order created and queued.`]
    };

    setWorkOrders(prev => [newOrder, ...prev]);

    setNotifications(prev => [
      {
        id: `notif-${Date.now()}`,
        title: `New Ticket: ${newOrder.id}`,
        description: `Unit ${newOrder.unitNumber} - ${newOrder.title}`,
        timestamp: 'Just now',
        unread: true,
        category: 'maintenance'
      },
      ...prev
    ]);
  };

  const updateWorkOrderStatus = (id: string, status: MaintenanceStatus, noteText?: string) => {
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10);
    
    setWorkOrders(prev => prev.map(wo => {
      if (wo.id === id) {
        const updatedNotes = [...wo.notes];
        if (noteText) {
          updatedNotes.push(`${dateStr}: [Status ${status}] ${noteText}`);
        } else {
          updatedNotes.push(`${dateStr}: Status marked as ${status}.`);
        }
        return {
          ...wo,
          status,
          updatedAt: `${dateStr} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
          notes: updatedNotes
        };
      }
      return wo;
    }));
  };

  const assignWorkOrderTech = (id: string, tech: string) => {
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10);
    
    setWorkOrders(prev => prev.map(wo => {
      if (wo.id === id) {
        return {
          ...wo,
          assignedTech: tech,
          status: wo.status === 'Submitted' ? 'Dispatched' : wo.status,
          updatedAt: `${dateStr} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
          notes: [...wo.notes, `${dateStr}: Dispatched to ${tech}.`]
        };
      }
      return wo;
    }));
  };

  const updateTurnStep = (turnId: string, stepIndex: number, completed: boolean) => {
    setTurns(prev => prev.map(turn => {
      if (turn.id === turnId) {
        const newSteps = [...turn.steps];
        newSteps[stepIndex] = { ...newSteps[stepIndex], completed };
        
        const allCompleted = newSteps.every(s => s.completed);
        const newStatus = allCompleted ? 'Inspection Passed' : 'In Progress';
        
        // If turn is finished, mark corresponding unit as Vacant Ready!
        if (allCompleted) {
          setUnits(prevUnits => prevUnits.map(u => {
            if (u.unitNumber === turn.unitNumber && u.propertyId === turn.propertyId) {
              return {
                ...u,
                status: 'Vacant Ready',
                isReadyForMoveIn: true,
                renovationTag: undefined
              };
            }
            return u;
          }));
        }

        return {
          ...turn,
          status: newStatus,
          steps: newSteps
        };
      }
      return turn;
    }));
  };

  const advanceProspectStage = (prospectId: string, stage: ProspectStage) => {
    setProspects(prev => prev.map(p => {
      if (p.id === prospectId) {
        return { ...p, stage };
      }
      return p;
    }));
  };

  const convertProspectToLease = (prospectId: string, unitId: string, monthlyRent: number, securityDeposit: number) => {
    const prospect = prospects.find(p => p.id === prospectId);
    const unit = units.find(u => u.id === unitId);
    if (!prospect || !unit) return;

    const leaseId = `lease-${unit.unitNumber}`;
    const today = new Date();
    const oneYearLater = new Date(today);
    oneYearLater.setFullYear(today.getFullYear() + 1);

    const newLease: Lease = {
      id: leaseId,
      propertyId: unit.propertyId,
      unitId: unit.id,
      unitNumber: unit.unitNumber,
      residentName: prospect.applicantName,
      email: prospect.email,
      phone: prospect.phone,
      leaseStartDate: today.toISOString().slice(0, 10),
      leaseEndDate: oneYearLater.toISOString().slice(0, 10),
      monthlyRent,
      securityDeposit,
      petRent: 35,
      parkingFee: 125,
      rubsFee: 75,
      balanceDue: 0,
      autopayEnabled: true,
      paymentStatus: 'Current',
      leaseStatus: 'Active',
      daysToExpiration: 365,
      insuranceVerified: true,
      emergencyContact: 'Contact on file'
    };

    // Update lease list
    setLeases(prev => [newLease, ...prev]);

    // Update unit status to Occupied
    setUnits(prev => prev.map(u => {
      if (u.id === unitId) {
        return {
          ...u,
          status: 'Occupied',
          actualRent: monthlyRent,
          currentResidentId: `res-${unit.unitNumber}`,
          currentResidentName: prospect.applicantName,
          leaseStartDate: newLease.leaseStartDate,
          leaseEndDate: newLease.leaseEndDate,
          depositHeld: securityDeposit,
          balanceDue: 0,
          isReadyForMoveIn: true
        };
      }
      return u;
    }));

    // Update prospect stage
    advanceProspectStage(prospectId, 'Signed & Deposit Paid');

    // Post security deposit & initial rent charge to ledger
    postTransaction({
      propertyId: unit.propertyId,
      unitNumber: unit.unitNumber,
      residentName: prospect.applicantName,
      date: today.toISOString().slice(0, 10),
      category: 'Security Deposit',
      amount: securityDeposit,
      type: 'Payment',
      method: 'ACH Direct'
    });
  };

  const sendRenewalOffer = (leaseId: string, proposedRent: number) => {
    setLeases(prev => prev.map(l => {
      if (l.id === leaseId) {
        return {
          ...l,
          renewalOfferSent: true,
          proposedRenewalRent: proposedRent,
          leaseStatus: 'Renewal Pending'
        };
      }
      return l;
    }));

    setNotifications(prev => [
      {
        id: `notif-${Date.now()}`,
        title: 'Lease Renewal Offer Dispatched',
        description: `Dispatched 12-month renewal to Lease #${leaseId} at $${proposedRent.toLocaleString()}/mo.`,
        timestamp: 'Just now',
        unread: true,
        category: 'leasing'
      },
      ...prev
    ]);
  };

  const acceptRenewalOffer = (leaseId: string) => {
    const target = leases.find(l => l.id === leaseId);
    if (!target) return;

    const newRent = target.proposedRenewalRent || target.monthlyRent;
    const currentEnd = new Date(target.leaseEndDate);
    const newEnd = new Date(currentEnd);
    newEnd.setFullYear(currentEnd.getFullYear() + 1);

    setLeases(prev => prev.map(l => {
      if (l.id === leaseId) {
        return {
          ...l,
          monthlyRent: newRent,
          leaseEndDate: newEnd.toISOString().slice(0, 10),
          leaseStatus: 'Active',
          renewalOfferSent: false,
          daysToExpiration: 365 + 30
        };
      }
      return l;
    }));

    // Update unit actual rent
    setUnits(prev => prev.map(u => {
      if (u.unitNumber === target.unitNumber && u.propertyId === target.propertyId) {
        return {
          ...u,
          actualRent: newRent,
          leaseEndDate: newEnd.toISOString().slice(0, 10)
        };
      }
      return u;
    }));
  };

  const submitNoticeToVacate = (unitId: string, leaseId: string, moveOutDate: string) => {
    const targetLease = leases.find(l => l.id === leaseId);
    const targetUnit = units.find(u => u.id === unitId);
    if (!targetLease || !targetUnit) return;

    // 1. Update lease
    setLeases(prev => prev.map(l => {
      if (l.id === leaseId) {
        return {
          ...l,
          leaseStatus: 'Notice to Vacate'
        };
      }
      return l;
    }));

    // 2. Update unit to Notice Given
    setUnits(prev => prev.map(u => {
      if (u.id === unitId) {
        return {
          ...u,
          status: 'Notice Given'
        };
      }
      return u;
    }));

    // 3. Automatically schedule Make-Ready Turn (The key Yardi/AppFolio automation!)
    const targetMoveIn = new Date(moveOutDate);
    targetMoveIn.setDate(targetMoveIn.getDate() + 10);

    const newTurn: MakeReadyTurn = {
      id: `TURN-${targetUnit.unitNumber}`,
      propertyId: targetUnit.propertyId,
      unitNumber: targetUnit.unitNumber,
      moveOutDate,
      targetMoveInDate: targetMoveIn.toISOString().slice(0, 10),
      status: 'In Progress',
      leadTech: 'Marcus Vance',
      budgetAllocated: 1250,
      actualCost: 0,
      notes: `Automated turn scheduled upon Notice to Vacate received from ${targetLease.residentName}.`,
      steps: [
        { name: '1. Key Intake & Move-Out Walk', completed: false, vendorOrTech: 'Leasing Staff', cost: 0 },
        { name: '2. Trashout & Bulk Removal', completed: false, vendorOrTech: 'EcoHaul Services', cost: 150 },
        { name: '3. Full Drywall Patch & Paint', completed: false, vendorOrTech: 'Apex Painting', cost: 450 },
        { name: '4. Vinyl Plank / Carpet Cleaning', completed: false, vendorOrTech: 'FloorCraft', cost: 350 },
        { name: '5. Mechanical & Appliance Tune', completed: false, vendorOrTech: 'Internal Tech', cost: 80 },
        { name: '6. Deep Make-Ready Clean', completed: false, vendorOrTech: 'Spotless Pro', cost: 120 },
        { name: '7. Final Walk & Move-In Key Encoding', completed: false, vendorOrTech: 'Property Manager', cost: 0 }
      ]
    };

    setTurns(prev => [newTurn, ...prev]);

    setNotifications(prev => [
      {
        id: `notif-${Date.now()}`,
        title: 'Notice to Vacate Logged',
        description: `Unit ${targetUnit.unitNumber} (${targetLease.residentName}) moving out on ${moveOutDate}. Make-Ready Turn #${newTurn.id} initialized.`,
        timestamp: 'Just now',
        unread: true,
        category: 'leasing'
      },
      ...prev
    ]);
  };

  const postTransaction = (txData: Omit<LedgerTransaction, 'id' | 'referenceNo' | 'status'>) => {
    const id = `TX-${Math.floor(1000 + Math.random() * 9000)}`;
    const refPrefix = txData.type === 'Payment' ? 'ACH' : 'CHG';
    const referenceNo = `${refPrefix}-${Math.floor(1000000 + Math.random() * 9000000)}`;

    const newTx: LedgerTransaction = {
      ...txData,
      id,
      referenceNo,
      status: 'Cleared'
    };

    setLedger(prev => [newTx, ...prev]);

    // Update lease / unit balance if relevant
    if (txData.type === 'Payment') {
      setLeases(prev => prev.map(l => {
        if (l.unitNumber === txData.unitNumber && l.propertyId === txData.propertyId) {
          const newBal = Math.max(0, l.balanceDue - txData.amount);
          return {
            ...l,
            balanceDue: newBal,
            paymentStatus: newBal === 0 ? 'Current' : l.paymentStatus
          };
        }
        return l;
      }));

      setUnits(prev => prev.map(u => {
        if (u.unitNumber === txData.unitNumber && u.propertyId === txData.propertyId) {
          return {
            ...u,
            balanceDue: Math.max(0, u.balanceDue - txData.amount)
          };
        }
        return u;
      }));
    } else if (txData.type === 'Charge') {
      setLeases(prev => prev.map(l => {
        if (l.unitNumber === txData.unitNumber && l.propertyId === txData.propertyId) {
          return {
            ...l,
            balanceDue: l.balanceDue + txData.amount
          };
        }
        return l;
      }));

      setUnits(prev => prev.map(u => {
        if (u.unitNumber === txData.unitNumber && u.propertyId === txData.propertyId) {
          return {
            ...u,
            balanceDue: u.balanceDue + txData.amount
          };
        }
        return u;
      }));
    }
  };

  // Resident Portal actions
  const residentPayRent = (amount: number, method: 'ACH Direct' | 'Credit Card') => {
    const today = new Date().toISOString().slice(0, 10);
    postTransaction({
      propertyId: 'prop-1',
      unitNumber: '412',
      residentName: 'Elena Rostova',
      date: today,
      category: 'Rent',
      amount,
      type: 'Payment',
      method
    });
  };

  const residentSubmitTicket = (category: any, title: string, description: string, entryPermission: boolean) => {
    addWorkOrder({
      propertyId: 'prop-1',
      unitNumber: '412',
      residentName: 'Elena Rostova',
      category,
      priority: 'Routine (72h)',
      status: 'Submitted',
      title,
      description,
      entryPermission,
      assignedTech: 'Unassigned',
      targetCompletion: new Date(Date.now() + 72 * 3600 * 1000).toISOString().slice(0, 10),
      laborHours: 0,
      partsCost: 0,
      notes: [`${new Date().toISOString().slice(0, 10)}: Submitted by resident via Resident Portal`]
    });
  };

  const claimPackage = (packageId: string) => {
    setPackages(prev => prev.map(pkg => {
      if (pkg.id === packageId) {
        return { ...pkg, pickedUp: true };
      }
      return pkg;
    }));
  };

  const bookAmenity = (amenityName: string, date: string, timeSlot: string) => {
    const newRes: AmenityReservation = {
      id: `RES-0${reservations.length + 1}`,
      amenityName,
      date,
      timeSlot,
      status: 'Confirmed'
    };
    setReservations(prev => [newRes, ...prev]);
  };

  const toggleAutopay = () => {
    setLeases(prev => prev.map(l => {
      if (l.unitNumber === '412' && l.propertyId === 'prop-1') {
        return { ...l, autopayEnabled: !l.autopayEnabled };
      }
      return l;
    }));
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, unread: false } : n));
  };

  const resetAllData = () => {
    localStorage.clear();
    setUnits(INITIAL_UNITS);
    setProspects(INITIAL_PROSPECTS);
    setLeases(INITIAL_LEASES);
    setWorkOrders(INITIAL_WORK_ORDERS);
    setTurns(INITIAL_TURNS);
    setLedger(INITIAL_LEDGER);
    setPackages(INITIAL_PACKAGES);
    setReservations(INITIAL_RESERVATIONS);
  };

  return (
    <PropertyContext.Provider
      value={{
        properties,
        units,
        prospects,
        leases,
        workOrders,
        turns,
        ledger,
        packages,
        reservations,
        notifications,
        selectedPropertyId,
        setSelectedPropertyId,
        activeRole,
        setActiveRole,
        activeTab,
        setActiveTab,
        searchQuery,
        setSearchQuery,
        currentProperty,
        filteredUnits,
        filteredLeases,
        filteredProspects,
        filteredWorkOrders,
        filteredTurns,
        filteredLedger,
        addWorkOrder,
        updateWorkOrderStatus,
        assignWorkOrderTech,
        updateTurnStep,
        advanceProspectStage,
        convertProspectToLease,
        sendRenewalOffer,
        acceptRenewalOffer,
        submitNoticeToVacate,
        postTransaction,
        residentPayRent,
        residentSubmitTicket,
        claimPackage,
        bookAmenity,
        toggleAutopay,
        markNotificationRead,
        resetAllData
      }}
    >
      {children}
    </PropertyContext.Provider>
  );
};

export const useProperty = () => {
  const context = useContext(PropertyContext);
  if (!context) {
    throw new Error('useProperty must be used within a PropertyProvider');
  }
  return context;
};
