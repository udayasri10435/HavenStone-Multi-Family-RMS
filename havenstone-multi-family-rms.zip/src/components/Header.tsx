import React, { useState, useRef, useEffect } from 'react';
import { useProperty } from '../context/PropertyContext';
import { UserRole } from '../types/property';
import { 
  Building2, 
  Search, 
  Bell, 
  Plus, 
  Wrench, 
  UserPlus, 
  DollarSign, 
  Calendar, 
  RotateCcw,
  Check,
  ChevronDown,
  Layers,
  UserCheck
} from 'lucide-react';
import { NewWorkOrderModal } from './Modals/NewWorkOrderModal';
import { NoticeToVacateModal } from './Modals/NoticeToVacateModal';
import { PostTransactionModal } from './Modals/PostTransactionModal';

export const Header: React.FC = () => {
  const { 
    properties, 
    selectedPropertyId, 
    setSelectedPropertyId, 
    activeRole, 
    setActiveRole, 
    activeTab, 
    setActiveTab, 
    searchQuery, 
    setSearchQuery,
    notifications,
    markNotificationRead,
    resetAllData
  } = useProperty();

  const [isQuickActionOpen, setIsQuickActionOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);

  // Modals state
  const [isWorkOrderModalOpen, setIsWorkOrderModalOpen] = useState(false);
  const [isNoticeModalOpen, setIsNoticeModalOpen] = useState(false);
  const [isPostTxModalOpen, setIsPostTxModalOpen] = useState(false);

  const quickActionRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);
  const roleRef = useRef<HTMLDivElement>(null);

  // Close popovers on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (quickActionRef.current && !quickActionRef.current.contains(e.target as Node)) {
        setIsQuickActionOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setIsNotifOpen(false);
      }
      if (roleRef.current && !roleRef.current.contains(e.target as Node)) {
        setIsRoleDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const unreadCount = notifications.filter(n => n.unread).length;

  const roleLabels: Record<UserRole, { label: string; roleDesc: string }> = {
    property_manager: { label: 'Property Manager', roleDesc: 'Portfolio Director' },
    leasing_agent: { label: 'Leasing Agent', roleDesc: 'Leasing & Occupancy' },
    maintenance_supervisor: { label: 'Maintenance Tech', roleDesc: 'Facilities & Turns' },
    resident_portal: { label: 'Resident View', roleDesc: 'Elena Rostova (Apt 412)' }
  };

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-slate-900/95 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-6 shrink-0">
            <button
              onClick={() => setActiveTab('dashboard')}
              className="text-lg font-bold tracking-tight text-white hover:text-blue-400 transition-colors flex items-center gap-2"
            >
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-xs">
                <Building2 className="w-4 h-4" />
              </div>
              <span className="font-semibold text-slate-100">HavenStone</span>
            </button>

            {/* Property Selector */}
            <div className="hidden lg:flex items-center">
              <select
                value={selectedPropertyId}
                onChange={e => setSelectedPropertyId(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-hidden focus:border-blue-500 hover:border-slate-700 transition-colors"
              >
                <option value="all">All Properties (Portfolio)</option>
                {properties.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Zone 2: 4-6 Clean text navigation links */}
          <nav className="hidden md:flex items-center gap-1 sm:gap-2 text-xs font-medium">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'dashboard'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              Overview
            </button>

            <button
              onClick={() => setActiveTab('leasing')}
              className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'leasing'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              Leasing & CRM
            </button>

            <button
              onClick={() => setActiveTab('maintenance')}
              className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'maintenance'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              Maintenance & Turns
            </button>

            <button
              onClick={() => setActiveTab('accounting')}
              className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'accounting'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              Accounting
            </button>

            <button
              onClick={() => setActiveTab('units')}
              className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'units'
                  ? 'bg-slate-800 text-white font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              Inventory
            </button>

            <button
              onClick={() => {
                setActiveRole('resident_portal');
                setActiveTab('resident_portal');
              }}
              className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'resident_portal'
                  ? 'bg-blue-600/20 text-blue-300 font-semibold border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              Resident Portal
            </button>
          </nav>

          {/* Zone 3: 1-2 Primary actions & Role Switcher */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Search Input */}
            <div className="relative hidden xl:block w-48">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                placeholder="Search unit, tenant, WO..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-hidden focus:border-blue-500"
              />
            </div>

            {/* Quick Action Button */}
            <div className="relative" ref={quickActionRef}>
              <button
                onClick={() => setIsQuickActionOpen(!isQuickActionOpen)}
                className="px-3 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Action</span>
                <ChevronDown className="w-3 h-3 text-blue-200" />
              </button>

              {isQuickActionOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-slate-900 border border-slate-800 rounded-xl shadow-xl py-1 z-50 text-xs">
                  <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                    Quick Operations
                  </div>
                  <button
                    onClick={() => {
                      setIsQuickActionOpen(false);
                      setIsWorkOrderModalOpen(true);
                    }}
                    className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 flex items-center gap-2 transition-colors"
                  >
                    <Wrench className="w-3.5 h-3.5 text-blue-400" />
                    Dispatch Work Order
                  </button>
                  <button
                    onClick={() => {
                      setIsQuickActionOpen(false);
                      setIsNoticeModalOpen(true);
                    }}
                    className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 flex items-center gap-2 transition-colors"
                  >
                    <Calendar className="w-3.5 h-3.5 text-amber-400" />
                    Log Notice to Vacate
                  </button>
                  <button
                    onClick={() => {
                      setIsQuickActionOpen(false);
                      setIsPostTxModalOpen(true);
                    }}
                    className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 flex items-center gap-2 transition-colors"
                  >
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                    Post Payment / Charge
                  </button>
                  <div className="border-t border-slate-800 mt-1 pt-1">
                    <button
                      onClick={() => {
                        setIsQuickActionOpen(false);
                        resetAllData();
                      }}
                      className="w-full text-left px-3 py-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 flex items-center gap-2 transition-colors text-[11px]"
                    >
                      <RotateCcw className="w-3 h-3 text-slate-500" />
                      Reset Demo State
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Notifications Bell */}
            <div className="relative" ref={notifRef}>
              <button
                onClick={() => setIsNotifOpen(!isNotifOpen)}
                className="relative p-2 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800 transition-colors"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-blue-500" />
                )}
              </button>

              {isNotifOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-slate-900 border border-slate-800 rounded-xl shadow-xl overflow-hidden z-50 text-xs">
                  <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
                    <span className="font-semibold text-slate-200">Alerts & System Events</span>
                    <span className="text-[11px] text-slate-400">{unreadCount} unread</span>
                  </div>
                  <div className="max-h-72 overflow-y-auto divide-y divide-slate-850">
                    {notifications.map(n => (
                      <div
                        key={n.id}
                        onClick={() => markNotificationRead(n.id)}
                        className={`p-3 cursor-pointer hover:bg-slate-800/60 transition-colors ${
                          n.unread ? 'bg-slate-850/40' : ''
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium text-slate-200">{n.title}</span>
                          <span className="text-[10px] text-slate-500">{n.timestamp}</span>
                        </div>
                        <p className="text-slate-400 text-[11px] leading-relaxed">{n.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Persona / Role Switcher */}
            <div className="relative" ref={roleRef}>
              <button
                onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
                className="flex items-center gap-2 pl-2 pr-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 hover:border-slate-700 text-xs transition-colors"
              >
                <div className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 font-mono text-[10px]">
                  {activeRole === 'resident_portal' ? 'R' : activeRole === 'maintenance_supervisor' ? 'M' : activeRole === 'leasing_agent' ? 'L' : 'P'}
                </div>
                <div className="text-left hidden sm:block">
                  <div className="text-[11px] font-medium text-slate-200 leading-tight">
                    {roleLabels[activeRole].label}
                  </div>
                </div>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {isRoleDropdownOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-xl shadow-xl py-1 z-50 text-xs">
                  <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                    Simulate User Persona
                  </div>
                  {(['property_manager', 'leasing_agent', 'maintenance_supervisor', 'resident_portal'] as UserRole[]).map(r => (
                    <button
                      key={r}
                      onClick={() => {
                        setActiveRole(r);
                        setIsRoleDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 flex items-center justify-between transition-colors ${
                        activeRole === r ? 'bg-slate-800 text-white font-medium' : 'text-slate-300 hover:bg-slate-850'
                      }`}
                    >
                      <div>
                        <div className="text-xs">{roleLabels[r].label}</div>
                        <div className="text-[11px] text-slate-400">{roleLabels[r].roleDesc}</div>
                      </div>
                      {activeRole === r && <Check className="w-4 h-4 text-blue-400 shrink-0" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Modals rendered globally */}
      <NewWorkOrderModal 
        isOpen={isWorkOrderModalOpen} 
        onClose={() => setIsWorkOrderModalOpen(false)} 
      />
      <NoticeToVacateModal 
        isOpen={isNoticeModalOpen} 
        onClose={() => setIsNoticeModalOpen(false)} 
      />
      <PostTransactionModal 
        isOpen={isPostTxModalOpen} 
        onClose={() => setIsPostTxModalOpen(false)} 
      />
    </>
  );
};
