import React, { useState } from 'react';
import { useProperty } from '../context/PropertyContext';
import { PropertyImageCard } from './PropertyImageCard';
import { 
  Building2, 
  TrendingUp, 
  Wrench, 
  AlertTriangle, 
  Users, 
  DollarSign, 
  Clock, 
  ArrowUpRight,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Calendar
} from 'lucide-react';
import { ApplicantReviewModal } from './Modals/ApplicantReviewModal';
import { Notice3DayModal } from './Modals/Notice3DayModal';
import { Prospect, Lease } from '../types/property';

export const DashboardView: React.FC = () => {
  const { 
    properties, 
    selectedPropertyId, 
    setSelectedPropertyId, 
    currentProperty,
    filteredUnits,
    filteredLeases,
    filteredWorkOrders,
    filteredTurns,
    filteredProspects,
    setActiveTab,
    units,
    leases,
    workOrders,
    turns
  } = useProperty();

  const [selectedProspect, setSelectedProspect] = useState<Prospect | null>(null);
  const [selectedLeaseForNotice, setSelectedLeaseForNotice] = useState<Lease | null>(null);

  // High-level aggregates
  const totalUnits = currentProperty ? currentProperty.totalUnits : properties.reduce((acc, p) => acc + p.totalUnits, 0);
  const occupiedUnits = currentProperty ? currentProperty.occupiedUnits : properties.reduce((acc, p) => acc + p.occupiedUnits, 0);
  const vacantUnits = currentProperty ? currentProperty.vacantUnits : properties.reduce((acc, p) => acc + p.vacantUnits, 0);
  const occupancyPct = Math.round((occupiedUnits / totalUnits) * 1000) / 10;

  const totalDelinquency = filteredLeases.reduce((acc, l) => acc + l.balanceDue, 0);
  const activeWorkOrdersCount = filteredWorkOrders.filter(w => w.status !== 'Completed').length;
  const emergencyWOCount = filteredWorkOrders.filter(w => w.priority.includes('Emergency') && w.status !== 'Completed').length;
  const inProgressTurnsCount = filteredTurns.filter(t => t.status === 'In Progress').length;
  const pendingApprovalsCount = filteredProspects.filter(p => p.stage === 'Screening Review' || p.stage === 'Application Submitted').length;

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner & Portfolio Switcher */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>Portfolio Operations</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-slate-300">
              {currentProperty ? `${currentProperty.name} (${currentProperty.code})` : 'All 3 Communities'}
            </span>
            <span aria-hidden="true">·</span>
            <span>Real-time T-12 & Occupancy Sync</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            {currentProperty ? currentProperty.name : 'Multi-Family Portfolio Dashboard'}
          </h1>
        </div>

        {/* Quick Scope Toggle */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-lg self-start md:self-auto">
          <button
            onClick={() => setSelectedPropertyId('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              selectedPropertyId === 'all'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Communities
          </button>
          {properties.map(p => (
            <button
              key={p.id}
              onClick={() => setSelectedPropertyId(p.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                selectedPropertyId === p.id
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {p.code}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Metric Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Occupancy */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4.5 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Physical Occupancy</span>
            <span className="text-emerald-400 font-mono text-[11px]">+0.4% MoM</span>
          </div>
          <div className="flex items-baseline gap-2 pt-1">
            <span className="text-2xl font-bold text-white font-mono tabular-nums">
              {occupancyPct}%
            </span>
            <span className="text-xs text-slate-400 font-mono tabular-nums">
              {occupiedUnits}/{totalUnits} units
            </span>
          </div>
          <div className="pt-2">
            <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
              <div 
                className="bg-emerald-500 h-1.5 rounded-full" 
                style={{ width: `${Math.min(100, occupancyPct)}%` }} 
              />
            </div>
          </div>
        </div>

        {/* Delinquency */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4.5 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Delinquency Balance</span>
            <span className={`text-[11px] font-mono ${totalDelinquency > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
              {currentProperty ? `${currentProperty.delinquencyRate}% of GPR` : '1.5% avg'}
            </span>
          </div>
          <div className="flex items-baseline gap-2 pt-1">
            <span className="text-2xl font-bold text-white font-mono tabular-nums">
              ${totalDelinquency.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400">uncollected</span>
          </div>
          <div className="text-[11px] text-slate-400 pt-1">
            {filteredLeases.filter(l => l.balanceDue > 0).length} accounts with open balance
          </div>
        </div>

        {/* Work Orders */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4.5 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Active Maintenance</span>
            {emergencyWOCount > 0 ? (
              <span className="text-rose-400 font-mono text-[11px] font-semibold flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                {emergencyWOCount} Emergency
              </span>
            ) : (
              <span className="text-emerald-400 font-mono text-[11px]">100% SLA Met</span>
            )}
          </div>
          <div className="flex items-baseline gap-2 pt-1">
            <span className="text-2xl font-bold text-white font-mono tabular-nums">
              {activeWorkOrdersCount}
            </span>
            <span className="text-xs text-slate-400">open tickets</span>
          </div>
          <div className="text-[11px] text-slate-400 pt-1">
            Avg resolution time: <span className="font-mono text-slate-200">14.2h</span>
          </div>
        </div>

        {/* Turns in Progress */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4.5 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Make-Ready Turns</span>
            <span className="text-blue-400 font-mono text-[11px]">Target: 7-Day</span>
          </div>
          <div className="flex items-baseline gap-2 pt-1">
            <span className="text-2xl font-bold text-white font-mono tabular-nums">
              {inProgressTurnsCount}
            </span>
            <span className="text-xs text-slate-400">units in turn</span>
          </div>
          <div className="text-[11px] text-slate-400 pt-1">
            {vacantUnits} total vacant ({vacantUnits - inProgressTurnsCount} ready for lease)
          </div>
        </div>
      </div>

      {/* Property Cards Strip (If Viewing Portfolio) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Communities & Asset Performance
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            {properties.length} Active Properties
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {properties.map(p => (
            <PropertyImageCard
              key={p.id}
              property={p}
              isSelected={selectedPropertyId === p.id}
              onClick={() => setSelectedPropertyId(p.id)}
            />
          ))}
        </div>
      </div>

      {/* Two Column Command Hub */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Urgent Operational Action Queue (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
              Priority Action Items
            </h2>
            <span className="text-xs text-slate-400">Requires Onsite Staff Review</span>
          </div>

          <div className="space-y-3">
            {/* Action Item: Emergency Work Order */}
            {filteredWorkOrders.find(w => w.priority.includes('Emergency') && w.status !== 'Completed') && (
              <div className="bg-rose-950/20 border border-rose-900/40 rounded-xl p-4 flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-rose-400 font-semibold font-mono">CRITICAL 4H SLA</span>
                    <span className="text-slate-500">·</span>
                    <span className="text-slate-300">Apt 101 (Julian Hayes)</span>
                  </div>
                  <h4 className="text-sm font-semibold text-white">
                    Water heater relief valve dripping into drain pan
                  </h4>
                  <p className="text-xs text-slate-400">
                    Water heater in utility closet has standing water in safety pan. Dispatch lead plumber immediately.
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('maintenance')}
                  className="px-3 py-1.5 text-xs font-medium bg-rose-600 hover:bg-rose-500 text-white rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Dispatch Tech
                </button>
              </div>
            )}

            {/* Action Item: Delinquent Account 3-Day Notice */}
            {filteredLeases.find(l => l.balanceDue >= 1000) && (
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-amber-400 font-semibold font-mono">DELINQUENT RENT</span>
                    <span className="text-slate-500">·</span>
                    <span className="text-slate-300">Unit 208 (Liam O’Connor)</span>
                  </div>
                  <h4 className="text-sm font-semibold text-white">
                    Account Past Due: $2,400.00 (16 Days to Lease Expiration)
                  </h4>
                  <p className="text-xs text-slate-400">
                    September rent unpaid. 3-Day Statutory Demand Notice prepared and ready for service.
                  </p>
                </div>
                <button
                  onClick={() => {
                    const delinquentLease = filteredLeases.find(l => l.balanceDue >= 1000) || filteredLeases[0];
                    setSelectedLeaseForNotice(delinquentLease);
                  }}
                  className="px-3 py-1.5 text-xs font-medium bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/30 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  View 3-Day Notice
                </button>
              </div>
            )}

            {/* Action Item: Application Underwriting */}
            {filteredProspects.find(p => p.stage === 'Screening Review') && (
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-emerald-400 font-semibold font-mono">SCREENING PASS</span>
                    <span className="text-slate-500">·</span>
                    <span className="text-slate-300">Samantha Green (Unit 315)</span>
                  </div>
                  <h4 className="text-sm font-semibold text-white">
                    Credit Score 742 · 3.8x Income Ratio Verified
                  </h4>
                  <p className="text-xs text-slate-400">
                    Application fee and holding deposit verified. Ready for lease generation and digital execution.
                  </p>
                </div>
                <button
                  onClick={() => {
                    const target = filteredProspects.find(p => p.stage === 'Screening Review') || filteredProspects[0];
                    setSelectedProspect(target);
                  }}
                  className="px-3 py-1.5 text-xs font-medium bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Review & Execute
                </button>
              </div>
            )}

            {/* Action Item: Active Turn Step */}
            {filteredTurns[0] && (
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-blue-400 font-semibold font-mono">MAKE-READY TURN</span>
                    <span className="text-slate-500">·</span>
                    <span className="text-slate-300">Unit {filteredTurns[0].unitNumber}</span>
                  </div>
                  <h4 className="text-sm font-semibold text-white">
                    Step 4: Vinyl Plank Flooring Installation scheduled
                  </h4>
                  <p className="text-xs text-slate-400">
                    Target ready date: <span className="font-mono text-slate-300">{filteredTurns[0].targetMoveInDate}</span> (Lead: {filteredTurns[0].leadTech})
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('maintenance')}
                  className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  View Checklist
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Live Occupancy & Financial Snapshot (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">Occupancy & Unit Distribution</h2>
            <button
              onClick={() => setActiveTab('units')}
              className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1"
            >
              Full Inventory <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-xs bg-emerald-500" />
                  Occupied Units
                </span>
                <span className="font-mono tabular-nums font-semibold">{occupiedUnits} units</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-xs bg-amber-500" />
                  Notice Given (Pre-Leasing)
                </span>
                <span className="font-mono tabular-nums font-semibold">
                  {filteredUnits.filter(u => u.status === 'Notice Given').length} units
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-xs bg-blue-500" />
                  Vacant Ready for Move-in
                </span>
                <span className="font-mono tabular-nums font-semibold">
                  {filteredUnits.filter(u => u.status === 'Vacant Ready').length} units
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-xs bg-purple-500" />
                  Vacant in Make-Ready Turn
                </span>
                <span className="font-mono tabular-nums font-semibold">
                  {filteredUnits.filter(u => u.status === 'Vacant Unready').length} units
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-xs bg-slate-500" />
                  Model / Office / Down
                </span>
                <span className="font-mono tabular-nums font-semibold">
                  {filteredUnits.filter(u => u.status === 'Model' || u.status === 'Down / Offline').length} units
                </span>
              </div>
            </div>

            {/* Financial Performance Mini-Card */}
            <div className="pt-4 border-t border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Gross Potential Rent (Monthly)</span>
                <span className="font-mono font-semibold text-slate-200 tabular-nums">
                  ${(totalUnits * 2350).toLocaleString()}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Net Operating Income (YTD)</span>
                <span className="font-mono font-semibold text-emerald-400 tabular-nums">
                  ${(currentProperty ? currentProperty.noiYTD : 7671100).toLocaleString()}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Operating Expense Ratio</span>
                <span className="font-mono text-slate-200 tabular-nums">38.4%</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setActiveTab('accounting')}
                className="w-full py-2 bg-slate-950 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 hover:text-white rounded-lg transition-colors flex items-center justify-center gap-2 font-medium"
              >
                <span>View Full P&L Statement (T-12)</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      <ApplicantReviewModal
        prospect={selectedProspect}
        isOpen={!!selectedProspect}
        onClose={() => setSelectedProspect(null)}
      />

      <Notice3DayModal
        lease={selectedLeaseForNotice}
        property={currentProperty}
        isOpen={!!selectedLeaseForNotice}
        onClose={() => setSelectedLeaseForNotice(null)}
      />
    </div>
  );
};
