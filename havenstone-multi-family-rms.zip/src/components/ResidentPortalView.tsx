import React, { useState } from 'react';
import { useProperty } from '../context/PropertyContext';
import { 
  Building2, 
  CreditCard, 
  Wrench, 
  Package, 
  Calendar, 
  FileText, 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  ArrowRight, 
  Plus, 
  X,
  AlertCircle
} from 'lucide-react';

export const ResidentPortalView: React.FC = () => {
  const { 
    leases, 
    workOrders, 
    packages, 
    reservations, 
    residentPayRent, 
    residentSubmitTicket, 
    claimPackage, 
    bookAmenity, 
    toggleAutopay,
    acceptRenewalOffer
  } = useProperty();

  // Find Elena Rostova's lease
  const myLease = leases.find(l => l.unitNumber === '412') || leases[0];
  const myTickets = workOrders.filter(w => w.unitNumber === '412');
  const activePackages = packages.filter(p => !p.pickedUp);

  // Modals & sub-state
  const [isPayModalOpen, setIsPayModalOpen] = useState(false);
  const [payAmount, setPayAmount] = useState<number>(myLease?.balanceDue > 0 ? myLease.balanceDue : 2450);
  const [payMethod, setPayMethod] = useState<'ACH Direct' | 'Credit Card'>('ACH Direct');
  const [isProcessingPay, setIsProcessingPay] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // New ticket state
  const [isTicketModalOpen, setIsTicketModalOpen] = useState(false);
  const [ticketCategory, setTicketCategory] = useState('HVAC');
  const [ticketTitle, setTicketTitle] = useState('');
  const [ticketDescription, setTicketDescription] = useState('');
  const [entryPermission, setEntryPermission] = useState(true);

  // Amenity booking state
  const [isAmenityModalOpen, setIsAmenityModalOpen] = useState(false);
  const [selectedAmenity, setSelectedAmenity] = useState('Rooftop Skyline Cabana #1');
  const [bookingDate, setBookingDate] = useState('2026-10-04');
  const [bookingSlot, setBookingSlot] = useState('2:00 PM – 6:00 PM');

  const handlePayRent = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessingPay(true);
    setTimeout(() => {
      residentPayRent(payAmount, payMethod);
      setIsProcessingPay(false);
      setPaymentSuccess(true);
      setTimeout(() => {
        setPaymentSuccess(false);
        setIsPayModalOpen(false);
      }, 1200);
    }, 800);
  };

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketTitle || !ticketDescription) return;

    residentSubmitTicket(ticketCategory, ticketTitle, ticketDescription, entryPermission);
    setTicketTitle('');
    setTicketDescription('');
    setIsTicketModalOpen(false);
  };

  const handleBookAmenity = (e: React.FormEvent) => {
    e.preventDefault();
    bookAmenity(selectedAmenity, bookingDate, bookingSlot);
    setIsAmenityModalOpen(false);
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Resident Welcome & Status Hero */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs font-mono text-blue-400">
            <span>RESIDENT PORTAL</span>
            <span className="text-slate-500">·</span>
            <span className="text-white font-semibold">The Mercer Grand · Apt 412</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Welcome home, Elena Rostova
          </h1>
          <p className="text-xs text-slate-400 max-w-xl">
            A2 · 1 Bed / 1 Bath Balcony · Lease active through {myLease.leaseEndDate}
          </p>
        </div>

        {/* Quick Balance Badge & Pay Action */}
        <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-5 shrink-0 min-w-[240px] text-right space-y-3">
          <div>
            <span className="text-[11px] text-slate-400 block font-mono">OCTOBER 1 RENT BALANCE</span>
            <div className="text-2xl font-bold font-mono tabular-nums text-white">
              {myLease.balanceDue > 0 ? `$${myLease.balanceDue.toLocaleString()}.00` : `$${myLease.monthlyRent.toLocaleString()}.00`}
            </div>
            <div className="text-[11px] text-slate-400 flex items-center justify-end gap-1.5 mt-0.5">
              <span>Autopay:</span>
              <span className={`font-semibold ${myLease.autopayEnabled ? 'text-emerald-400' : 'text-slate-400'}`}>
                {myLease.autopayEnabled ? 'Active (Oct 1)' : 'Off'}
              </span>
            </div>
          </div>

          <button
            onClick={() => setIsPayModalOpen(true)}
            className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            Pay Rent Online
          </button>
        </div>
      </div>

      {/* Renewal Notification Banner (If renewal offer sent) */}
      {myLease.renewalOfferSent && (
        <div className="bg-blue-950/30 border border-blue-900/50 rounded-xl p-4.5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-mono text-blue-400">
              <Calendar className="w-3.5 h-3.5" />
              <span>LEASE RENEWAL OFFER AVAILABLE</span>
            </div>
            <h3 className="text-sm font-semibold text-white">
              Lock in your Apt 412 rate for another 12 months at ${myLease.proposedRenewalRent?.toLocaleString() || '2,540'}/mo
            </h3>
            <p className="text-xs text-slate-400">
              Avoid market rate increases. Complete your renewal agreement with 1-click digital confirmation.
            </p>
          </div>
          <button
            onClick={() => acceptRenewalOffer(myLease.id)}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shadow-xs self-start sm:self-auto"
          >
            Accept 12-Mo Renewal
          </button>
        </div>
      )}

      {/* Main Grid: Rent & Payments, Service Requests, Packages */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Payments & Service Requests */}
        <div className="lg:col-span-7 space-y-6">
          {/* Active Maintenance Requests */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
                  <Wrench className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Maintenance & Service Requests</h3>
                  <p className="text-xs text-slate-400">Real-time status updates from our onsite facilities team</p>
                </div>
              </div>

              <button
                onClick={() => setIsTicketModalOpen(true)}
                className="px-3 py-1.5 text-xs font-medium text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
              >
                <Plus className="w-3 h-3" />
                Request Service
              </button>
            </div>

            <div className="space-y-3">
              {myTickets.length === 0 ? (
                <div className="text-center py-6 text-xs text-slate-500 italic">
                  No open service requests. Everything in Unit 412 is working smoothly!
                </div>
              ) : (
                myTickets.map(ticket => (
                  <div key={ticket.id} className="bg-slate-950/60 border border-slate-800 rounded-lg p-3.5 space-y-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400">
                          <span className="text-slate-200 font-semibold">{ticket.id}</span>
                          <span>·</span>
                          <span>{ticket.category}</span>
                          <span>·</span>
                          <span className="text-blue-400">{ticket.status}</span>
                        </div>
                        <h4 className="text-xs font-semibold text-slate-100 mt-0.5">{ticket.title}</h4>
                      </div>
                      <span className="text-[11px] font-mono text-slate-400">{ticket.createdAt}</span>
                    </div>

                    <p className="text-xs text-slate-400 leading-relaxed">{ticket.description}</p>

                    {ticket.assignedTech && ticket.assignedTech !== 'Unassigned' && (
                      <div className="text-[11px] text-slate-400 border-t border-slate-850 pt-1.5 flex items-center justify-between">
                        <span>Assigned Lead: <strong className="text-slate-300 font-medium">{ticket.assignedTech}</strong></span>
                        <span className="text-emerald-400">Target ETA: Today by 5:00 PM</span>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Smart Package Locker Concierge */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                  <Package className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Smart Package Concierge</h3>
                  <p className="text-xs text-slate-400">Deliveries in building parcel lockers</p>
                </div>
              </div>
              <span className="text-xs font-mono text-slate-400">
                {activePackages.length} Ready for Pickup
              </span>
            </div>

            <div className="space-y-3">
              {packages.map(pkg => (
                <div
                  key={pkg.id}
                  className={`p-3.5 rounded-lg border flex items-center justify-between gap-4 transition-colors ${
                    pkg.pickedUp 
                      ? 'bg-slate-950/30 border-slate-850 opacity-60' 
                      : 'bg-slate-950/80 border-slate-800'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-semibold text-slate-200">{pkg.carrier} Delivery</span>
                      <span className="text-slate-500">·</span>
                      <span className="font-mono text-slate-400">{pkg.lockerNumber}</span>
                    </div>
                    <div className="text-xs text-slate-400">
                      Delivered {pkg.deliveredAt} · Tracking ending in <span className="font-mono">{pkg.trackingLast4}</span>
                    </div>
                    {!pkg.pickedUp && (
                      <div className="pt-1 flex items-center gap-2">
                        <span className="text-xs text-slate-400">Locker Code:</span>
                        <span className="text-sm font-bold font-mono tabular-nums tracking-widest text-emerald-400 bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-900/40">
                          {pkg.pickupCode}
                        </span>
                      </div>
                    )}
                  </div>

                  {!pkg.pickedUp ? (
                    <button
                      onClick={() => claimPackage(pkg.id)}
                      className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors whitespace-nowrap"
                    >
                      Mark Picked Up
                    </button>
                  ) : (
                    <span className="text-xs text-slate-500 font-mono">Retrieved</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Amenity Bookings & Lease Documents */}
        <div className="lg:col-span-5 space-y-6">
          {/* Amenity Reservations */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <Calendar className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Amenity Reservations</h3>
                  <p className="text-xs text-slate-400">Clubhouse, rooftop cabanas & focus pods</p>
                </div>
              </div>

              <button
                onClick={() => setIsAmenityModalOpen(true)}
                className="px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-md transition-colors"
              >
                + Book
              </button>
            </div>

            <div className="space-y-2.5">
              {reservations.map(res => (
                <div key={res.id} className="bg-slate-950/60 border border-slate-800 rounded-lg p-3 space-y-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200">{res.amenityName}</span>
                    <span className="text-[11px] font-mono text-emerald-400">{res.status}</span>
                  </div>
                  <div className="text-slate-400 font-mono text-[11px] flex items-center justify-between">
                    <span>{res.date}</span>
                    <span>{res.timeSlot}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Lease Summary & Insurance Verification */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-semibold text-white">Lease Agreement & Compliance</span>
              <span className="text-emerald-400 font-medium flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> Verified
              </span>
            </div>

            <div className="space-y-2 pt-1 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">Renter&apos;s Insurance Policy:</span>
                <span className="font-mono text-slate-200">Lemonade #LM-9820-A</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Coverage Minimum:</span>
                <span className="font-mono text-slate-200">$100,000 Liability (Valid)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Security Deposit on File:</span>
                <span className="font-mono tabular-nums text-slate-200">${myLease.securityDeposit.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Assigned Parking Bay:</span>
                <span className="font-mono text-slate-200">Stall #B-24 (Level 2)</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">Automatic Rent Autopay:</span>
              <button
                onClick={toggleAutopay}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                  myLease.autopayEnabled 
                    ? 'bg-emerald-600 text-white' 
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                {myLease.autopayEnabled ? 'Autopay Enabled' : 'Enable Autopay'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Pay Rent Modal */}
      {isPayModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-md shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-semibold text-white">Online Rent Remittance</h3>
              <button onClick={() => setIsPayModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            {paymentSuccess ? (
              <div className="py-8 text-center space-y-2">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
                <h4 className="text-base font-semibold text-white">Payment Authorized</h4>
                <p className="text-xs text-slate-400 font-mono">
                  ACH Ref #ACH-{Math.floor(1000000 + Math.random() * 9000000)} · Confirmed
                </p>
              </div>
            ) : (
              <form onSubmit={handlePayRent} className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Amount to Remit ($ USD)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={payAmount}
                    onChange={e => setPayAmount(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-base font-mono tabular-nums text-white focus:outline-hidden focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Payment Method</label>
                  <div className="space-y-2">
                    <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-800 bg-slate-950 cursor-pointer">
                      <input
                        type="radio"
                        name="method"
                        checked={payMethod === 'ACH Direct'}
                        onChange={() => setPayMethod('ACH Direct')}
                        className="text-blue-500 focus:ring-0"
                      />
                      <div>
                        <div className="font-semibold text-slate-200">Chase Checking (•••• 8921)</div>
                        <div className="text-[11px] text-slate-500 font-mono">ACH Direct Debit · 0% transaction fee</div>
                      </div>
                    </label>

                    <label className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-800 bg-slate-950 cursor-pointer">
                      <input
                        type="radio"
                        name="method"
                        checked={payMethod === 'Credit Card'}
                        onChange={() => setPayMethod('Credit Card')}
                        className="text-blue-500 focus:ring-0"
                      />
                      <div>
                        <div className="font-semibold text-slate-200">Visa Signature (•••• 4018)</div>
                        <div className="text-[11px] text-slate-500 font-mono">Card Network · 2.9% fee applies</div>
                      </div>
                    </label>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsPayModalOpen(false)}
                    className="px-4 py-2 text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isProcessingPay}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg font-semibold"
                  >
                    {isProcessingPay ? 'Authorizing NACHA...' : `Authorize $${payAmount.toLocaleString()}`}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Request Service Modal */}
      {isTicketModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-md shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-semibold text-white">Submit Maintenance Request</h3>
              <button onClick={() => setIsTicketModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTicket} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Issue Category</label>
                <select
                  value={ticketCategory}
                  onChange={e => setTicketCategory(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-hidden focus:border-blue-500"
                >
                  <option value="HVAC">HVAC / Air Conditioning</option>
                  <option value="Plumbing">Plumbing / Water leak</option>
                  <option value="Appliance">Kitchen Appliance</option>
                  <option value="Electrical">Electrical / Lighting</option>
                  <option value="Locks / Access">Lock / Keypad</option>
                  <option value="General">General Repair</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Brief Summary</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dishwasher leaking water onto kitchen tile"
                  value={ticketTitle}
                  onChange={e => setTicketTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Description & Details</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Describe when the issue occurs and any troubleshooting you have tried..."
                  value={ticketDescription}
                  onChange={e => setTicketDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 cursor-pointer text-slate-300 select-none">
                  <input
                    type="checkbox"
                    checked={entryPermission}
                    onChange={e => setEntryPermission(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-950 text-blue-500 focus:ring-0"
                  />
                  <span>Maintenance has permission to enter Unit 412 if absent</span>
                </label>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsTicketModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold"
                >
                  Submit Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Book Amenity Modal */}
      {isAmenityModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-md shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-semibold text-white">Reserve Community Amenity</h3>
              <button onClick={() => setIsAmenityModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleBookAmenity} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Amenity Space</label>
                <select
                  value={selectedAmenity}
                  onChange={e => setSelectedAmenity(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-hidden focus:border-blue-500"
                >
                  <option value="Rooftop Skyline Cabana #1">Rooftop Skyline Cabana #1</option>
                  <option value="Rooftop Skyline Cabana #2">Rooftop Skyline Cabana #2</option>
                  <option value="Private Focus Co-Working Pod A">Private Focus Co-Working Pod A</option>
                  <option value="Private Focus Co-Working Pod B">Private Focus Co-Working Pod B</option>
                  <option value="Demonstration Chef Kitchen & Lounge">Chef Demonstration Kitchen & Lounge</option>
                  <option value="Reserved Level 2 EV Fast Charger">Level 2 EV Fast Charging Stall</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Reservation Date</label>
                <input
                  type="date"
                  required
                  value={bookingDate}
                  onChange={e => setBookingDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Time Slot Window</label>
                <select
                  value={bookingSlot}
                  onChange={e => setBookingSlot(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-hidden focus:border-blue-500"
                >
                  <option value="9:00 AM – 1:00 PM">Morning (9:00 AM – 1:00 PM)</option>
                  <option value="2:00 PM – 6:00 PM">Afternoon (2:00 PM – 6:00 PM)</option>
                  <option value="6:30 PM – 10:30 PM">Evening (6:30 PM – 10:30 PM)</option>
                </select>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAmenityModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold"
                >
                  Confirm Reservation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
