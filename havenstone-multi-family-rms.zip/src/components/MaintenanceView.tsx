import React, { useState } from 'react';
import { useProperty } from '../context/PropertyContext';
import { MaintenancePriority, MaintenanceStatus, WorkOrder, MakeReadyTurn } from '../types/property';
import { 
  Wrench, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  CheckSquare, 
  Square, 
  User, 
  Calendar, 
  DollarSign, 
  Plus, 
  ChevronRight,
  ShieldAlert,
  Flame,
  Key
} from 'lucide-react';
import { NewWorkOrderModal } from './Modals/NewWorkOrderModal';

export const MaintenanceView: React.FC = () => {
  const { 
    filteredWorkOrders, 
    filteredTurns, 
    updateWorkOrderStatus, 
    assignWorkOrderTech, 
    updateTurnStep,
    addWorkOrder
  } = useProperty();

  const [activeSubTab, setActiveSubTab] = useState<'dispatch' | 'turns' | 'preventive'>('dispatch');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedWorkOrder, setSelectedWorkOrder] = useState<WorkOrder | null>(null);
  const [isNewWOModalOpen, setIsNewWOModalOpen] = useState(false);

  // Quick note state for selected work order
  const [newNoteText, setNewNoteText] = useState('');

  const activeOrders = filteredWorkOrders.filter(w => {
    const matchPriority = priorityFilter === 'all' || w.priority.startsWith(priorityFilter);
    const matchStatus = statusFilter === 'all' || w.status === statusFilter;
    return matchPriority && matchStatus;
  });

  const handleAddNote = (woId: string) => {
    if (!newNoteText.trim()) return;
    updateWorkOrderStatus(woId, selectedWorkOrder?.status || 'In Progress', newNoteText.trim());
    setNewNoteText('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* View Header & Subtabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Facilities & Turn Operations</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time work order dispatch, SLA compliance, and multi-family make-ready unit turns
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Subtabs Bar */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg self-start sm:self-auto">
            <button
              onClick={() => setActiveSubTab('dispatch')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeSubTab === 'dispatch'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Work Orders ({filteredWorkOrders.filter(w => w.status !== 'Completed').length})
            </button>
            <button
              onClick={() => setActiveSubTab('turns')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeSubTab === 'turns'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Make-Ready Turns ({filteredTurns.length})
            </button>
            <button
              onClick={() => setActiveSubTab('preventive')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeSubTab === 'preventive'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Asset Schedules
            </button>
          </div>

          <button
            onClick={() => setIsNewWOModalOpen(true)}
            className="px-3 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Ticket</span>
          </button>
        </div>
      </div>

      {/* SUBTAB 1: WORK ORDER DISPATCH QUEUE */}
      {activeSubTab === 'dispatch' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 border border-slate-800 p-3 rounded-xl text-xs">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-slate-400">SLA Priority:</span>
                <select
                  value={priorityFilter}
                  onChange={e => setPriorityFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-200 focus:outline-hidden focus:border-blue-500"
                >
                  <option value="all">All Priorities</option>
                  <option value="Emergency">Emergency (4h)</option>
                  <option value="High">High (24h)</option>
                  <option value="Routine">Routine (72h)</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-slate-400">Status:</span>
                <select
                  value={statusFilter}
                  onChange={e => setStatusFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-200 focus:outline-hidden focus:border-blue-500"
                >
                  <option value="all">All Statuses</option>
                  <option value="Submitted">Submitted (New)</option>
                  <option value="Dispatched">Dispatched</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Awaiting Parts">Awaiting Parts</option>
                  <option value="Completed">Completed</option>
                </select>
              </div>
            </div>

            <span className="text-slate-500 font-mono text-[11px]">
              Showing {activeOrders.length} tickets
            </span>
          </div>

          {/* Work Orders List & Selected Detail Drawer */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Orders Table (7 cols) */}
            <div className="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-950/70 text-slate-400 font-mono uppercase tracking-wider text-[10px]">
                      <th className="py-2.5 px-3">Ticket / Unit</th>
                      <th className="py-2.5 px-3">Category & Scope</th>
                      <th className="py-2.5 px-3">Priority / SLA</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3">Tech</th>
                      <th className="py-2.5 px-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850">
                    {activeOrders.map(wo => {
                      const isEmergency = wo.priority.includes('Emergency');
                      const isSelected = selectedWorkOrder?.id === wo.id;

                      return (
                        <tr
                          key={wo.id}
                          onClick={() => setSelectedWorkOrder(wo)}
                          className={`cursor-pointer transition-colors ${
                            isSelected ? 'bg-blue-950/30' : 'hover:bg-slate-850/50'
                          }`}
                        >
                          <td className="py-2.5 px-3 font-mono">
                            <span className="text-slate-100 font-semibold block">{wo.id}</span>
                            <span className="text-slate-400 text-[11px]">Apt {wo.unitNumber}</span>
                          </td>

                          <td className="py-2.5 px-3">
                            <div className="font-medium text-slate-200 truncate max-w-[200px]">
                              {wo.title}
                            </div>
                            <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                              <span>{wo.category}</span>
                              <span>·</span>
                              <span>{wo.residentName}</span>
                            </div>
                          </td>

                          <td className="py-2.5 px-3">
                            <span className={`text-[11px] font-mono ${
                              isEmergency ? 'text-rose-400 font-semibold flex items-center gap-1' :
                              wo.priority.includes('High') ? 'text-amber-400' :
                              'text-slate-400'
                            }`}>
                              {isEmergency && <Flame className="w-3 h-3 text-rose-500 shrink-0" />}
                              {wo.priority}
                            </span>
                          </td>

                          <td className="py-2.5 px-3">
                            <span className={`text-[11px] ${
                              wo.status === 'Completed' ? 'text-emerald-400' :
                              wo.status === 'In Progress' ? 'text-blue-400 font-medium' :
                              wo.status === 'Awaiting Parts' ? 'text-amber-400' :
                              'text-slate-300'
                            }`}>
                              {wo.status}
                            </span>
                          </td>

                          <td className="py-2.5 px-3 text-slate-300 text-[11px]">
                            {wo.assignedTech}
                          </td>

                          <td className="py-2.5 px-3 text-right">
                            <ChevronRight className="w-4 h-4 text-slate-500 inline-block" />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Selected Work Order Inspector (5 cols) */}
            <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-5">
              {selectedWorkOrder ? (
                <>
                  <div className="flex items-start justify-between border-b border-slate-800 pb-3">
                    <div>
                      <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                        <span className="text-white font-semibold">{selectedWorkOrder.id}</span>
                        <span>·</span>
                        <span>Unit {selectedWorkOrder.unitNumber}</span>
                        <span>·</span>
                        <span>Created {selectedWorkOrder.createdAt}</span>
                      </div>
                      <h3 className="text-sm font-semibold text-white mt-1">
                        {selectedWorkOrder.title}
                      </h3>
                    </div>
                  </div>

                  {/* Status & Tech Control */}
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-slate-400 mb-1">Update Status</label>
                      <select
                        value={selectedWorkOrder.status}
                        onChange={e => {
                          const newStatus = e.target.value as MaintenanceStatus;
                          updateWorkOrderStatus(selectedWorkOrder.id, newStatus);
                          setSelectedWorkOrder({ ...selectedWorkOrder, status: newStatus });
                        }}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-hidden focus:border-blue-500"
                      >
                        <option value="Submitted">Submitted (New)</option>
                        <option value="Dispatched">Dispatched</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Awaiting Parts">Awaiting Parts</option>
                        <option value="Completed">Completed (Close Ticket)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-400 mb-1">Assigned Tech</label>
                      <select
                        value={selectedWorkOrder.assignedTech}
                        onChange={e => {
                          const newTech = e.target.value;
                          assignWorkOrderTech(selectedWorkOrder.id, newTech);
                          setSelectedWorkOrder({ ...selectedWorkOrder, assignedTech: newTech });
                        }}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-hidden focus:border-blue-500"
                      >
                        <option value="Marcus Vance">Marcus Vance (HVAC)</option>
                        <option value="David Chen">David Chen (Plumbing)</option>
                        <option value="Elena Ruiz">Elena Ruiz (Appliance)</option>
                        <option value="Ray Morales">Ray Morales (Access)</option>
                        <option value="External Vendor">External Vendor</option>
                      </select>
                    </div>
                  </div>

                  {/* Resident Info & Permissions */}
                  <div className="bg-slate-950/70 border border-slate-800/80 rounded-lg p-3 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="text-slate-400">Resident:</span>
                      <span className="font-semibold">{selectedWorkOrder.residentName}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="text-slate-400">Permission to Enter:</span>
                      <span className={`font-medium ${selectedWorkOrder.entryPermission ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {selectedWorkOrder.entryPermission ? 'Yes (Enter if absent)' : 'Call first / Present'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="text-slate-400">Target SLA Deadline:</span>
                      <span className="font-mono text-slate-200">{selectedWorkOrder.targetCompletion}</span>
                    </div>
                  </div>

                  {/* Work Description */}
                  <div>
                    <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                      Resident Description
                    </h4>
                    <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/40 p-3 rounded-lg border border-slate-800/60">
                      {selectedWorkOrder.description}
                    </p>
                  </div>

                  {/* Activity Journal & Technician Notes */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                      Work Log & Notes ({selectedWorkOrder.notes.length})
                    </h4>
                    <div className="space-y-1.5 max-h-36 overflow-y-auto">
                      {selectedWorkOrder.notes.map((n, idx) => (
                        <div key={idx} className="text-[11px] text-slate-300 bg-slate-950/60 p-2 rounded border border-slate-850 font-mono">
                          {n}
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <input
                        type="text"
                        placeholder="Add technician log entry..."
                        value={newNoteText}
                        onChange={e => setNewNoteText(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && handleAddNote(selectedWorkOrder.id)}
                        className="flex-1 bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-hidden focus:border-blue-500"
                      />
                      <button
                        onClick={() => handleAddNote(selectedWorkOrder.id)}
                        className="px-2.5 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-medium transition-colors"
                      >
                        Add Log
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-slate-500 space-y-2">
                  <Wrench className="w-8 h-8 stroke-[1.2]" />
                  <p className="text-xs">Select any ticket from the queue to view full diagnostics, assign technicians, or update repair logs.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: MAKE-READY UNIT TURN BOARD */}
      {activeSubTab === 'turns' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white">Active Make-Ready Unit Turn Board</h2>
              <p className="text-xs text-slate-400">
                Standardized 7-step multi-family unit turnover workflow. Checking all steps automatically releases the unit as Vacant Ready.
              </p>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {filteredTurns.length} Units in Turnover
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredTurns.map(turn => {
              const completedCount = turn.steps.filter(s => s.completed).length;
              const progressPct = Math.round((completedCount / turn.steps.length) * 100);

              return (
                <div key={turn.id} className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4 shadow-xs">
                  <div className="flex items-start justify-between border-b border-slate-800 pb-3">
                    <div>
                      <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                        <span className="text-blue-400 font-semibold">{turn.id}</span>
                        <span>·</span>
                        <span className="text-white font-bold">Apt {turn.unitNumber}</span>
                        <span>·</span>
                        <span>Move-out: {turn.moveOutDate}</span>
                      </div>
                      <h3 className="text-sm font-semibold text-slate-100 mt-1">
                        Turn Lead: {turn.leadTech}
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">{turn.notes}</p>
                    </div>

                    <div className="text-right">
                      <span className={`text-xs font-semibold ${
                        turn.status === 'Inspection Passed' ? 'text-emerald-400' : 'text-blue-400'
                      }`}>
                        {turn.status}
                      </span>
                      <div className="text-[11px] font-mono tabular-nums text-slate-400 mt-0.5">
                        Target Ready: {turn.targetMoveInDate}
                      </div>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-mono tabular-nums text-slate-400">
                      <span>{completedCount} of {turn.steps.length} Steps Completed</span>
                      <span className="text-slate-200 font-semibold">{progressPct}%</span>
                    </div>
                    <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
                      <div 
                        className={`h-1.5 rounded-full transition-all duration-300 ${
                          progressPct === 100 ? 'bg-emerald-500' : 'bg-blue-500'
                        }`} 
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                  </div>

                  {/* Turn Steps Interactive Checklist */}
                  <div className="space-y-2 pt-1">
                    {turn.steps.map((step, idx) => (
                      <div
                        key={idx}
                        onClick={() => updateTurnStep(turn.id, idx, !step.completed)}
                        className={`flex items-center justify-between p-2.5 rounded-lg border text-xs cursor-pointer transition-colors ${
                          step.completed
                            ? 'bg-emerald-950/20 border-emerald-900/40 text-slate-300'
                            : 'bg-slate-950/60 border-slate-800/80 text-slate-200 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          {step.completed ? (
                            <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-500 shrink-0" />
                          )}
                          <span className={step.completed ? 'line-through text-slate-400' : 'font-medium'}>
                            {step.name}
                          </span>
                        </div>

                        <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
                          <span>{step.vendorOrTech}</span>
                          {step.cost ? <span>${step.cost}</span> : null}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Turn Financials */}
                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs font-mono tabular-nums">
                    <span className="text-slate-400">Budget: ${turn.budgetAllocated.toLocaleString()}</span>
                    <span className="text-slate-200 font-semibold">Actual Spent: ${turn.actualCost.toLocaleString()}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUBTAB 3: PREVENTIVE MAINTENANCE SCHEDULE */}
      {activeSubTab === 'preventive' && (
        <div className="space-y-4">
          <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-4">
            <h3 className="text-sm font-semibold text-white">Institutional Asset Compliance & Preventive Maintenance</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Tracks mandatory mechanical checks, backflow certifications, boiler inspections, and HVAC filter cycles.
            </p>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/70 text-slate-400 font-mono uppercase tracking-wider text-[10px]">
                  <th className="py-2.5 px-3">Equipment / Asset</th>
                  <th className="py-2.5 px-3">Cadence</th>
                  <th className="py-2.5 px-3">Last Completed</th>
                  <th className="py-2.5 px-3">Next Due</th>
                  <th className="py-2.5 px-3">Vendor / Tech</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                <tr className="hover:bg-slate-850/50">
                  <td className="py-3 px-3 text-slate-100 font-semibold">Building A & B Central Chiller Plant</td>
                  <td className="py-3 px-3 text-slate-400">Quarterly</td>
                  <td className="py-3 px-3 font-mono text-slate-400">2026-07-15</td>
                  <td className="py-3 px-3 font-mono text-emerald-400 font-semibold">2026-10-15</td>
                  <td className="py-3 px-3 text-slate-300">Carrier Commercial</td>
                  <td className="py-3 px-3 text-emerald-400 font-medium">Nominal</td>
                </tr>
                <tr className="hover:bg-slate-850/50">
                  <td className="py-3 px-3 text-slate-100 font-semibold">Fire Sprinkler Backflow Preventers (3 Valves)</td>
                  <td className="py-3 px-3 text-slate-400">Annual</td>
                  <td className="py-3 px-3 font-mono text-slate-400">2025-10-02</td>
                  <td className="py-3 px-3 font-mono text-amber-400 font-semibold">2026-10-02 (4 Days)</td>
                  <td className="py-3 px-3 text-slate-300">Austin Fire & Safety</td>
                  <td className="py-3 px-3 text-amber-400 font-medium">Inspection Scheduled</td>
                </tr>
                <tr className="hover:bg-slate-850/50">
                  <td className="py-3 px-3 text-slate-100 font-semibold">Passenger Elevator Hydraulic Jack Seal #1 & #2</td>
                  <td className="py-3 px-3 text-slate-400">Monthly</td>
                  <td className="py-3 px-3 font-mono text-slate-400">2026-09-01</td>
                  <td className="py-3 px-3 font-mono text-slate-200">2026-10-01</td>
                  <td className="py-3 px-3 text-slate-300">Otis Elevator Co.</td>
                  <td className="py-3 px-3 text-emerald-400 font-medium">Passed</td>
                </tr>
                <tr className="hover:bg-slate-850/50">
                  <td className="py-3 px-3 text-slate-100 font-semibold">Quarterly Resident Unit HVAC Filter Swap (240 Units)</td>
                  <td className="py-3 px-3 text-slate-400">Quarterly</td>
                  <td className="py-3 px-3 font-mono text-slate-400">2026-06-20</td>
                  <td className="py-3 px-3 font-mono text-blue-400 font-semibold">2026-09-30</td>
                  <td className="py-3 px-3 text-slate-300">Marcus Vance & Techs</td>
                  <td className="py-3 px-3 text-blue-400 font-medium">210/240 Completed</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal */}
      <NewWorkOrderModal
        isOpen={isNewWOModalOpen}
        onClose={() => setIsNewWOModalOpen(false)}
      />
    </div>
  );
};
