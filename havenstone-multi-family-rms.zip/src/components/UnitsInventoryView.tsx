import React, { useState } from 'react';
import { useProperty } from '../context/PropertyContext';
import { UnitStatus, Unit } from '../types/property';
import { 
  Building2, 
  Search, 
  Filter, 
  Plus, 
  Home, 
  Wrench, 
  Calendar,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { NewWorkOrderModal } from './Modals/NewWorkOrderModal';
import { NoticeToVacateModal } from './Modals/NoticeToVacateModal';

export const UnitsInventoryView: React.FC = () => {
  const { filteredUnits, properties, selectedPropertyId } = useProperty();
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [floorPlanFilter, setFloorPlanFilter] = useState<string>('all');

  const [selectedUnitForWO, setSelectedUnitForWO] = useState<string>('');
  const [selectedUnitForNotice, setSelectedUnitForNotice] = useState<string>('');

  const floorPlans = Array.from(new Set(filteredUnits.map(u => u.floorPlan)));

  const displayedUnits = filteredUnits.filter(u => {
    const matchStatus = statusFilter === 'all' || u.status === statusFilter;
    const matchPlan = floorPlanFilter === 'all' || u.floorPlan === floorPlanFilter;
    return matchStatus && matchPlan;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Unit Inventory & Stacking Matrix</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Physical inventory status, floor plans, market rental rates, and make-ready availability
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-slate-400">
            {displayedUnits.length} of {filteredUnits.length} Units Displayed
          </span>
        </div>
      </div>

      {/* Filter Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 border border-slate-800 p-3 rounded-xl text-xs">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Occupancy Status:</span>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-200 focus:outline-hidden focus:border-blue-500"
            >
              <option value="all">All Statuses</option>
              <option value="Occupied">Occupied</option>
              <option value="Notice Given">Notice Given</option>
              <option value="Vacant Ready">Vacant Ready</option>
              <option value="Vacant Unready">Vacant Unready</option>
              <option value="Model">Model / Office</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-400">Floor Plan:</span>
            <select
              value={floorPlanFilter}
              onChange={e => setFloorPlanFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-200 focus:outline-hidden focus:border-blue-500"
            >
              <option value="all">All Layouts</option>
              {floorPlans.map(plan => (
                <option key={plan} value={plan}>{plan}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Units Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {displayedUnits.map(u => {
          const isOccupied = u.status === 'Occupied';
          const isReady = u.status === 'Vacant Ready';
          const isTurn = u.status === 'Vacant Unready';
          const isNotice = u.status === 'Notice Given';

          return (
            <div
              key={u.id}
              className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded-xl p-4 space-y-3 transition-colors shadow-xs"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-lg font-bold font-mono text-white">Unit {u.unitNumber}</span>
                    <span className="text-xs text-slate-400">{u.building}</span>
                  </div>
                  <span className="text-xs text-slate-300 font-medium block mt-0.5">{u.floorPlan}</span>
                </div>

                <span className={`text-[11px] font-medium px-2 py-0.5 rounded-md ${
                  isOccupied ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-900/40' :
                  isNotice ? 'bg-amber-950/40 text-amber-400 border border-amber-900/40' :
                  isReady ? 'bg-blue-950/40 text-blue-400 border border-blue-900/40' :
                  isTurn ? 'bg-purple-950/40 text-purple-400 border border-purple-900/40' :
                  'bg-slate-800 text-slate-300'
                }`}>
                  {u.status}
                </span>
              </div>

              {/* Specs & Pricing */}
              <div className="grid grid-cols-2 gap-2 text-xs font-mono tabular-nums bg-slate-950/60 p-2.5 rounded-lg border border-slate-850">
                <div>
                  <span className="text-[10px] text-slate-500 font-sans block uppercase">Size</span>
                  <span className="text-slate-200">{u.sqft} sqft · Flr {u.floor}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-sans block uppercase">Market Rent</span>
                  <span className="text-slate-200 font-semibold">${u.marketRent.toLocaleString()}/mo</span>
                </div>
              </div>

              {/* Resident or Turn status */}
              <div className="text-xs text-slate-400 space-y-1">
                {isOccupied && (
                  <div>
                    <span className="text-slate-500">Resident:</span>{' '}
                    <span className="text-slate-200 font-medium">{u.currentResidentName}</span>
                    <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                      In-Place: ${u.actualRent.toLocaleString()}/mo · Lease ends {u.leaseEndDate}
                    </div>
                  </div>
                )}

                {isNotice && (
                  <div>
                    <span className="text-amber-400 font-semibold">Notice on File:</span>{' '}
                    <span className="text-slate-300">{u.currentResidentName}</span>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Pre-leasing for move-in after {u.leaseEndDate}
                    </div>
                  </div>
                )}

                {isReady && (
                  <div className="text-blue-400 font-medium flex items-center gap-1.5 pt-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Turn Completed & Clean · Ready for Move-In
                  </div>
                )}

                {isTurn && (
                  <div className="text-purple-400 text-[11px] flex items-center gap-1.5 pt-1">
                    <Wrench className="w-3.5 h-3.5" />
                    {u.renovationTag || 'Make-Ready Turn underway'}
                  </div>
                )}
              </div>

              {/* Unit Card Actions */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <button
                  onClick={() => setSelectedUnitForWO(u.unitNumber)}
                  className="text-slate-400 hover:text-blue-400 flex items-center gap-1 transition-colors"
                >
                  <Wrench className="w-3 h-3" />
                  Work Order
                </button>

                {isOccupied && (
                  <button
                    onClick={() => setSelectedUnitForNotice(u.unitNumber)}
                    className="text-slate-400 hover:text-amber-400 flex items-center gap-1 transition-colors"
                  >
                    <Calendar className="w-3 h-3" />
                    Notice
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modals */}
      <NewWorkOrderModal
        defaultUnit={selectedUnitForWO}
        isOpen={!!selectedUnitForWO}
        onClose={() => setSelectedUnitForWO('')}
      />

      <NoticeToVacateModal
        defaultUnitNumber={selectedUnitForNotice}
        isOpen={!!selectedUnitForNotice}
        onClose={() => setSelectedUnitForNotice('')}
      />
    </div>
  );
};
