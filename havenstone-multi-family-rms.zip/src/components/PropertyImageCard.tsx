import React from 'react';
import { Property } from '../types/property';
import { Building2, MapPin, KeyRound, TrendingUp } from 'lucide-react';

interface PropertyImageCardProps {
  property: Property;
  onClick?: () => void;
  isSelected?: boolean;
}

export const PropertyImageCard: React.FC<PropertyImageCardProps> = ({ property, onClick, isSelected }) => {
  return (
    <div
      onClick={onClick}
      className={`group relative overflow-hidden rounded-xl border transition-all cursor-pointer ${
        isSelected 
          ? 'border-blue-500 bg-slate-900/90 shadow-md ring-1 ring-blue-500/20' 
          : 'border-slate-800 bg-slate-900/50 hover:border-slate-700 hover:bg-slate-900/80'
      }`}
    >
      {/* Visual Architectural Facade Simulation */}
      <div className="relative h-32 w-full overflow-hidden bg-gradient-to-br from-slate-900 via-slate-850 to-slate-950 flex items-center justify-center border-b border-slate-800/80">
        {/* Subtle grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:16px_16px] opacity-25" />

        {/* Isometric architectural silhouette */}
        <div className="relative z-10 flex flex-col items-center">
          <div className="w-12 h-12 rounded-xl bg-slate-850/80 border border-slate-700/60 flex items-center justify-center text-blue-400 group-hover:scale-105 transition-transform duration-300 shadow-inner">
            <Building2 className="w-6 h-6 stroke-[1.5]" />
          </div>
          <span className="text-[11px] font-mono tracking-widest uppercase text-slate-400 mt-2 font-medium">
            {property.code} · {property.assetClass}
          </span>
        </div>

        {/* Occupancy Badge */}
        <div className="absolute top-2.5 right-2.5 z-20">
          <span className="text-[11px] font-mono tabular-nums text-slate-200 bg-slate-950/80 border border-slate-800 px-2 py-0.5 rounded-md">
            {property.physicalOccupancy}% Occ
          </span>
        </div>
      </div>

      {/* Property Details */}
      <div className="p-4 space-y-2">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 group-hover:text-blue-400 transition-colors">
              {property.name}
            </h3>
            <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
              <MapPin className="w-3 h-3 text-slate-500" />
              {property.address}, {property.city}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/60 text-xs font-mono tabular-nums">
          <div>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-sans">Units</span>
            <span className="text-slate-200 font-semibold">{property.occupiedUnits}/{property.totalUnits}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-sans">Avg Rent</span>
            <span className="text-slate-200 font-semibold">${property.avgMarketRent.toLocaleString()}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-sans">Delinq</span>
            <span className={`font-semibold ${property.delinquencyRate > 2.0 ? 'text-amber-400' : 'text-slate-200'}`}>
              {property.delinquencyRate}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
