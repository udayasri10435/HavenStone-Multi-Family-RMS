import React from 'react';
import { Lease, Property } from '../../types/property';
import { X, Printer, AlertTriangle, Download } from 'lucide-react';

interface Notice3DayModalProps {
  lease: Lease | null;
  property: Property | null;
  isOpen: boolean;
  onClose: () => void;
}

export const Notice3DayModal: React.FC<Notice3DayModalProps> = ({ lease, property, isOpen, onClose }) => {
  if (!isOpen || !lease) return null;

  const todayStr = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  const deadlineDate = new Date();
  deadlineDate.setDate(deadlineDate.getDate() + 3);
  const deadlineStr = deadlineDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100">Notice to Pay Rent or Quit</h3>
              <p className="text-xs text-slate-400">Statutory 3-Day Demand Notice for Nonpayment of Rent</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Legal Notice Preview Document */}
        <div className="p-8 overflow-y-auto bg-slate-950 text-slate-200 text-xs font-mono leading-relaxed space-y-4 border-b border-slate-800">
          <div className="text-center pb-4 border-b border-slate-800 space-y-1">
            <h2 className="text-base font-bold uppercase tracking-wider text-white">NOTICE TO PAY RENT OR SURRENDER POSSESSION</h2>
            <p className="text-[11px] text-slate-400">(THREE-DAY NOTICE UNDER STATE PROPERTY STATUTES)</p>
          </div>

          <div className="grid grid-cols-2 gap-4 py-2">
            <div>
              <span className="text-slate-500 block">TO TENANT(S):</span>
              <span className="text-white font-bold text-sm block">{lease.residentName}</span>
              <span className="text-slate-400 block">AND ALL OTHERS IN POSSESSION</span>
              <span className="text-slate-300 block">Unit {lease.unitNumber}</span>
              <span className="text-slate-400 block">{property?.address || 'Community Premises'}, {property?.city || 'Austin'}, {property?.state || 'TX'} {property?.zip || ''}</span>
            </div>
            <div>
              <span className="text-slate-500 block">DATE OF SERVICE:</span>
              <span className="text-white font-semibold">{todayStr}</span>
              <span className="text-slate-500 block mt-2">TOTAL DELINQUENT BALANCE:</span>
              <span className="text-rose-400 font-bold text-base tabular-nums">${lease.balanceDue.toLocaleString()}.00</span>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <p>
              PLEASE TAKE NOTICE that pursuant to the lease agreement under which you hold possession of the above-described premises, there is now due, unpaid, and delinquent rent in the sum of <strong className="text-white tabular-nums">${lease.balanceDue.toLocaleString()}.00</strong>.
            </p>
            <p>
              WITHIN THREE (3) DAYS after service of this Notice upon you, you are required to pay the full sum stated above by cashier&apos;s check, certified funds, or verified electronic ACH remittance, OR SURRENDER AND DELIVER POSSESSION of the premises to the management.
            </p>
            <p>
              PAYMENT DEADLINE: <strong className="text-amber-400">{deadlineStr} by 5:00 PM CST</strong>.
            </p>
            <p className="text-slate-400 text-[11px]">
              If you fail to either pay the total amount or surrender possession within the statutory time, legal proceedings will be commenced against you to recover possession, treble damages, attorney fees, and costs of suit as authorized by law.
            </p>
          </div>

          <div className="pt-6 border-t border-slate-800 grid grid-cols-2 gap-6 text-[11px]">
            <div>
              <p className="text-slate-400">Authorized Agent / Management Signature:</p>
              <div className="mt-3 border-b border-slate-700 w-48 h-8 font-serif italic text-sm text-slate-300 flex items-end">
                HavenStone Asset Operations
              </div>
              <p className="text-slate-500 mt-1">Property Director on behalf of Landlord</p>
            </div>
            <div>
              <p className="text-slate-400">Office Location for Remittance:</p>
              <p className="text-slate-300 font-sans mt-1">{property?.name || 'HavenStone Leasing Office'}</p>
              <p className="text-slate-400 font-sans">{property?.address || '450 S Congress Ave'}</p>
              <p className="text-slate-400 font-sans">Hours: Mon-Fri 9:00 AM - 6:00 PM</p>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 flex items-center justify-between bg-slate-900">
          <span className="text-xs text-slate-400">
            Certified Delivery Tracking # <span className="font-mono text-slate-300">HS-DEMAND-{lease.unitNumber}-2026</span>
          </span>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
            >
              Close
            </button>
            <button
              onClick={handlePrint}
              className="px-4 py-2 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / Save PDF
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
