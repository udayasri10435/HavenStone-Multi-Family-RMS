import React, { useState } from 'react';
import { useProperty } from '../../context/PropertyContext';
import { X, Calendar, AlertCircle } from 'lucide-react';

interface NoticeToVacateModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultUnitNumber?: string;
}

export const NoticeToVacateModal: React.FC<NoticeToVacateModalProps> = ({ isOpen, onClose, defaultUnitNumber }) => {
  const { units, leases, submitNoticeToVacate } = useProperty();
  const [selectedUnitNumber, setSelectedUnitNumber] = useState(defaultUnitNumber || '');
  const [moveOutDate, setMoveOutDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    return d.toISOString().slice(0, 10);
  });
  const [reason, setReason] = useState('Job Relocation');

  if (!isOpen) return null;

  const occupiedUnits = units.filter(u => u.status === 'Occupied');
  const matchedUnit = units.find(u => u.unitNumber === selectedUnitNumber);
  const matchedLease = leases.find(l => l.unitNumber === selectedUnitNumber && l.leaseStatus !== 'Notice to Vacate');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!matchedUnit || !matchedLease) return;
    submitNoticeToVacate(matchedUnit.id, matchedLease.id, moveOutDate);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100">Log Notice to Vacate</h3>
              <p className="text-xs text-slate-400">Records resident intent to vacate and provisions unit turn</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Occupied Unit & Resident</label>
            <select
              value={selectedUnitNumber}
              onChange={e => setSelectedUnitNumber(e.target.value)}
              required
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-amber-500"
            >
              <option value="">Select occupied unit...</option>
              {occupiedUnits.map(u => (
                <option key={u.id} value={u.unitNumber}>
                  Apt {u.unitNumber} - {u.currentResidentName || 'Resident on file'} (${u.actualRent}/mo)
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Scheduled Move-Out Date</label>
            <input
              type="date"
              required
              value={moveOutDate}
              onChange={e => setMoveOutDate(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Reason for Non-Renewal / Move Out</label>
            <select
              value={reason}
              onChange={e => setReason(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-amber-500"
            >
              <option value="Job Relocation">Job Relocation / Transfer</option>
              <option value="Purchased Single Family Home">Purchased Single Family Home</option>
              <option value="Rent Rate / Price Sensitivity">Rent Rate / Price Sensitivity</option>
              <option value="Downsizing / Upsizing">Downsizing or Upsizing</option>
              <option value="Personal / Family Reasons">Personal / Family Reasons</option>
              <option value="Unsatisfactory Experience">Community / Service Experience</option>
            </select>
          </div>

          <div className="bg-amber-950/20 border border-amber-800/30 rounded-lg p-3 text-xs text-amber-300 flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold block">Automatic Operations Trigger</span>
              Submitting notice will immediately mark the unit as <span className="font-semibold text-white">Notice Given</span> and provision Make-Ready Turn schedule for maintenance punchlist coordination.
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!selectedUnitNumber}
              className="px-4 py-2 text-xs font-medium bg-amber-600 hover:bg-amber-500 text-white rounded-lg shadow-sm transition-colors disabled:opacity-50"
            >
              Confirm Notice & Schedule Turn
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
