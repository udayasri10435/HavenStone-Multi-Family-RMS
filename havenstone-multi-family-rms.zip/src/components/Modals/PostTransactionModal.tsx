import React, { useState } from 'react';
import { useProperty } from '../../context/PropertyContext';
import { X, DollarSign } from 'lucide-react';

interface PostTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultUnitNumber?: string;
}

export const PostTransactionModal: React.FC<PostTransactionModalProps> = ({ isOpen, onClose, defaultUnitNumber }) => {
  const { properties, units, postTransaction, selectedPropertyId } = useProperty();

  const [propertyId, setPropertyId] = useState(
    selectedPropertyId !== 'all' ? selectedPropertyId : properties[0]?.id || ''
  );
  const [unitNumber, setUnitNumber] = useState(defaultUnitNumber || '');
  const [residentName, setResidentName] = useState('');
  const [type, setType] = useState<'Charge' | 'Payment'>('Payment');
  const [category, setCategory] = useState<'Rent' | 'Late Fee' | 'RUBS Utility' | 'Parking' | 'Pet Fee' | 'Security Deposit' | 'Work Order Charge'>('Rent');
  const [amount, setAmount] = useState<number>(0);
  const [method, setMethod] = useState<'ACH Direct' | 'Credit Card' | 'Check / Money Order'>('ACH Direct');

  if (!isOpen) return null;

  const currentPropUnits = units.filter(u => u.propertyId === propertyId);

  const handleUnitChange = (uNum: string) => {
    setUnitNumber(uNum);
    const matched = currentPropUnits.find(u => u.unitNumber === uNum);
    if (matched?.currentResidentName) {
      setResidentName(matched.currentResidentName);
      if (amount === 0 && type === 'Payment') {
        setAmount(matched.balanceDue > 0 ? matched.balanceDue : matched.actualRent);
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!unitNumber || amount <= 0) return;

    postTransaction({
      propertyId,
      unitNumber,
      residentName: residentName || 'Resident on File',
      date: new Date().toISOString().slice(0, 10),
      category,
      amount,
      type,
      method: type === 'Payment' ? method : undefined
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <DollarSign className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100">Post Ledger Transaction</h3>
              <p className="text-xs text-slate-400">Post charges, utility assessments, or resident payments</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="flex items-center gap-2 p-1 bg-slate-950 border border-slate-800 rounded-lg">
            <button
              type="button"
              onClick={() => setType('Payment')}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors ${
                type === 'Payment' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Post Payment Received
            </button>
            <button
              type="button"
              onClick={() => setType('Charge')}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors ${
                type === 'Charge' ? 'bg-slate-800 text-amber-400 shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Post New Charge / Assessment
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Property</label>
              <select
                value={propertyId}
                onChange={e => {
                  setPropertyId(e.target.value);
                  setUnitNumber('');
                }}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-blue-500"
              >
                {properties.map(p => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Unit / Resident</label>
              <select
                value={unitNumber}
                onChange={e => handleUnitChange(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-blue-500"
              >
                <option value="">Select unit...</option>
                {currentPropUnits.map(u => (
                  <option key={u.id} value={u.unitNumber}>
                    Apt {u.unitNumber} - {u.currentResidentName || u.status} (Bal: ${u.balanceDue})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">GL Category</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-blue-500"
              >
                <option value="Rent">Base Rent</option>
                <option value="RUBS Utility">RUBS / Water & Sewer</option>
                <option value="Late Fee">Late Assessment Fee</option>
                <option value="Parking">Reserved Parking Bay</option>
                <option value="Pet Fee">Pet Rent</option>
                <option value="Security Deposit">Security Deposit</option>
                <option value="Work Order Charge">Billable Work Order</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Amount ($ USD)</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                required
                placeholder="0.00"
                value={amount || ''}
                onChange={e => setAmount(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono tabular-nums text-slate-200 focus:outline-hidden focus:border-blue-500"
              />
            </div>
          </div>

          {type === 'Payment' && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Remittance Method</label>
              <select
                value={method}
                onChange={e => setMethod(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-blue-500"
              >
                <option value="ACH Direct">Bank ACH Direct Debit (Plaid / NACHA)</option>
                <option value="Credit Card">Credit Card (Stripe / Worldpay)</option>
                <option value="Check / Money Order">Cashier Check / WIPS Cash Network</option>
              </select>
            </div>
          )}

          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={amount <= 0 || !unitNumber}
              className="px-4 py-2 text-xs font-medium bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg shadow-sm transition-colors whitespace-nowrap"
            >
              {type === 'Payment' ? 'Post Payment Received' : 'Post Charge to Ledger'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
