import React, { useState } from 'react';
import { useProperty } from '../../context/PropertyContext';
import { MaintenanceCategory, MaintenancePriority } from '../../types/property';
import { X, Wrench, AlertTriangle, Clock } from 'lucide-react';

interface NewWorkOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultUnit?: string;
}

export const NewWorkOrderModal: React.FC<NewWorkOrderModalProps> = ({ isOpen, onClose, defaultUnit }) => {
  const { properties, units, addWorkOrder, selectedPropertyId } = useProperty();

  const [propertyId, setPropertyId] = useState(
    selectedPropertyId !== 'all' ? selectedPropertyId : properties[0]?.id || ''
  );
  const [unitNumber, setUnitNumber] = useState(defaultUnit || '');
  const [residentName, setResidentName] = useState('');
  const [category, setCategory] = useState<MaintenanceCategory>('Plumbing');
  const [priority, setPriority] = useState<MaintenancePriority>('Routine (72h)');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [entryPermission, setEntryPermission] = useState(true);
  const [assignedTech, setAssignedTech] = useState('Marcus Vance');

  if (!isOpen) return null;

  const currentPropUnits = units.filter(u => u.propertyId === propertyId);

  const handleUnitChange = (uNum: string) => {
    setUnitNumber(uNum);
    const matchedUnit = currentPropUnits.find(u => u.unitNumber === uNum);
    if (matchedUnit?.currentResidentName) {
      setResidentName(matchedUnit.currentResidentName);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!unitNumber || !title || !description) return;

    const targetHours = priority.startsWith('Emergency') ? 4 : priority.startsWith('High') ? 24 : 72;
    const targetDate = new Date(Date.now() + targetHours * 3600 * 1000).toISOString().slice(0, 10);

    addWorkOrder({
      propertyId,
      unitNumber,
      residentName: residentName || 'Resident on File',
      category,
      priority,
      status: assignedTech !== 'Unassigned' ? 'Dispatched' : 'Submitted',
      title,
      description,
      entryPermission,
      assignedTech,
      targetCompletion: targetDate,
      laborHours: 0,
      partsCost: 0,
      notes: []
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <Wrench className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100">Create Work Order</h3>
              <p className="text-xs text-slate-400">Dispatch maintenance or service repair ticket</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Property Community</label>
              <select
                value={propertyId}
                onChange={e => {
                  setPropertyId(e.target.value);
                  setUnitNumber('');
                  setResidentName('');
                }}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-blue-500"
              >
                {properties.map(p => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Unit Number</label>
              <select
                value={unitNumber}
                onChange={e => handleUnitChange(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-blue-500"
              >
                <option value="">Select unit...</option>
                {currentPropUnits.map(u => (
                  <option key={u.id} value={u.unitNumber}>
                    Apt {u.unitNumber} {u.currentResidentName ? `(${u.currentResidentName})` : `[${u.status}]`}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Trade Category</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as MaintenanceCategory)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-blue-500"
              >
                <option value="HVAC">HVAC / Cooling & Heating</option>
                <option value="Plumbing">Plumbing / Water Lines</option>
                <option value="Electrical">Electrical / Lighting</option>
                <option value="Appliance">Appliance / Refrigeration</option>
                <option value="Locks / Access">Locks & Access Control</option>
                <option value="Carpentry">Carpentry & Drywall</option>
                <option value="General">General Maintenance</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Priority & SLA</label>
              <select
                value={priority}
                onChange={e => setPriority(e.target.value as MaintenancePriority)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-blue-500"
              >
                <option value="Routine (72h)">Routine (72h SLA)</option>
                <option value="High (24h)">High Priority (24h SLA)</option>
                <option value="Emergency (4h)">Emergency (4h Critical SLA)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Issue Title</label>
            <input
              type="text"
              required
              placeholder="e.g. Master bath lavatory drain leaking into vanity"
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Scope of Work & Diagnostics</label>
            <textarea
              required
              rows={3}
              placeholder="Provide exact details, equipment model numbers if known, and troubleshooting steps taken..."
              value={description}
              onChange={e => setDescription(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Assign Lead Technician</label>
              <select
                value={assignedTech}
                onChange={e => setAssignedTech(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-blue-500"
              >
                <option value="Marcus Vance">Marcus Vance (HVAC Lead)</option>
                <option value="David Chen">David Chen (Master Plumber)</option>
                <option value="Elena Ruiz">Elena Ruiz (General / Appliances)</option>
                <option value="Ray Morales">Ray Morales (Access & Electrical)</option>
                <option value="Unassigned">Unassigned (Hold in Queue)</option>
              </select>
            </div>

            <div className="flex items-center pt-6">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300 select-none">
                <input
                  type="checkbox"
                  checked={entryPermission}
                  onChange={e => setEntryPermission(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-950 text-blue-500 focus:ring-0 w-4 h-4"
                />
                <span>Resident granted permission to enter</span>
              </label>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-medium bg-blue-600 hover:bg-blue-500 text-white rounded-lg shadow-sm transition-colors whitespace-nowrap"
            >
              Dispatch Work Order
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
