import React, { useState } from 'react';
import { useProperty } from '../../context/PropertyContext';
import { Prospect } from '../../types/property';
import { X, ShieldCheck, CheckCircle2, UserCheck, FileText, Ban } from 'lucide-react';

interface ApplicantReviewModalProps {
  prospect: Prospect | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ApplicantReviewModal: React.FC<ApplicantReviewModalProps> = ({ prospect, isOpen, onClose }) => {
  const { units, convertProspectToLease, advanceProspectStage } = useProperty();
  const [selectedUnitId, setSelectedUnitId] = useState(prospect?.assignedUnitId || '');
  const [monthlyRent, setMonthlyRent] = useState<number>(0);
  const [securityDeposit, setSecurityDeposit] = useState<number>(0);
  const [isExecuting, setIsExecuting] = useState(false);

  React.useEffect(() => {
    if (prospect) {
      const targetUnit = units.find(u => u.id === (prospect.assignedUnitId || selectedUnitId));
      if (targetUnit) {
        setSelectedUnitId(targetUnit.id);
        setMonthlyRent(targetUnit.marketRent);
        setSecurityDeposit(targetUnit.marketRent);
      } else {
        const available = units.find(u => u.propertyId === prospect.propertyId && (u.status === 'Vacant Ready' || u.status === 'Vacant Unready'));
        if (available) {
          setSelectedUnitId(available.id);
          setMonthlyRent(available.marketRent);
          setSecurityDeposit(available.marketRent);
        }
      }
    }
  }, [prospect, units]);

  if (!isOpen || !prospect) return null;

  const currentUnit = units.find(u => u.id === selectedUnitId);
  const availableUnits = units.filter(u => u.propertyId === prospect.propertyId && (u.status === 'Vacant Ready' || u.id === prospect.assignedUnitId));

  const handleUnitSelect = (id: string) => {
    setSelectedUnitId(id);
    const u = units.find(unit => unit.id === id);
    if (u) {
      setMonthlyRent(u.marketRent);
      setSecurityDeposit(u.marketRent);
    }
  };

  const handleExecuteLease = () => {
    if (!selectedUnitId) return;
    setIsExecuting(true);
    setTimeout(() => {
      convertProspectToLease(prospect.id, selectedUnitId, monthlyRent, securityDeposit);
      setIsExecuting(false);
      onClose();
    }, 600);
  };

  const handleSendLeasePacket = () => {
    advanceProspectStage(prospect.id, 'Lease Sent');
    onClose();
  };

  const handleDeny = () => {
    advanceProspectStage(prospect.id, 'Denied');
    onClose();
  };

  const isCreditStrong = prospect.creditScore >= 670;
  const isIncomeSufficient = prospect.incomeToRentRatio >= 3.0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100">{prospect.applicantName}</h3>
              <p className="text-xs text-slate-400">
                Application Review · Applied {prospect.applicationDate} · Desired Move-in {prospect.desiredMoveIn}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto">
          {/* Underwriting Matrix */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">Underwriting & Screening Metrics</h4>
            <div className="grid grid-cols-3 gap-3">
              {/* Credit Score */}
              <div className="bg-slate-950/80 border border-slate-800/80 rounded-lg p-3.5">
                <span className="text-xs text-slate-400 block mb-1">Experian Credit Score</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-semibold font-mono tabular-nums text-slate-100">
                    {prospect.creditScore}
                  </span>
                  <span className={`text-xs font-medium ${isCreditStrong ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {isCreditStrong ? 'Tier 1 Prime' : 'Conditional'}
                  </span>
                </div>
                <span className="text-[11px] text-slate-500 block mt-1">Min. threshold: 650</span>
              </div>

              {/* Income Ratio */}
              <div className="bg-slate-950/80 border border-slate-800/80 rounded-lg p-3.5">
                <span className="text-xs text-slate-400 block mb-1">Gross Income Ratio</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-semibold font-mono tabular-nums text-slate-100">
                    {prospect.incomeToRentRatio}x
                  </span>
                  <span className={`text-xs font-medium ${isIncomeSufficient ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {isIncomeSufficient ? 'Passed (≥3.0x)' : 'Below Policy'}
                  </span>
                </div>
                <span className="text-[11px] text-slate-500 block mt-1 font-mono tabular-nums">
                  ${prospect.monthlyIncome.toLocaleString()}/mo verified
                </span>
              </div>

              {/* Background Status */}
              <div className="bg-slate-950/80 border border-slate-800/80 rounded-lg p-3.5">
                <span className="text-xs text-slate-400 block mb-1">Criminal & Eviction</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-sm font-semibold text-emerald-400 flex items-center gap-1.5 pt-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Verified Clean
                  </span>
                </div>
                <span className="text-[11px] text-slate-500 block mt-1">No prior filings</span>
              </div>
            </div>
          </div>

          {/* Contact & Bio Details */}
          <div className="bg-slate-950/40 border border-slate-800/60 rounded-lg p-4 space-y-2 text-xs">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="text-slate-500">Contact Email:</span>{' '}
                <span className="text-slate-300 font-mono">{prospect.email}</span>
              </div>
              <div>
                <span className="text-slate-500">Mobile Phone:</span>{' '}
                <span className="text-slate-300 font-mono">{prospect.phone}</span>
              </div>
            </div>
            <div>
              <span className="text-slate-500">Screening Notes:</span>{' '}
              <span className="text-slate-300">{prospect.notes}</span>
            </div>
          </div>

          {/* Lease Assignment Execution */}
          <div className="space-y-3 pt-2 border-t border-slate-800">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">Unit Allocation & Financial Terms</h4>
            
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Target Unit</label>
                <select
                  value={selectedUnitId}
                  onChange={e => handleUnitSelect(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-hidden focus:border-blue-500"
                >
                  <option value="">Select available unit...</option>
                  {availableUnits.map(u => (
                    <option key={u.id} value={u.id}>
                      Unit {u.unitNumber} ({u.floorPlan}) - ${u.marketRent}/mo
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Monthly In-Place Rent ($)</label>
                <input
                  type="number"
                  value={monthlyRent}
                  onChange={e => setMonthlyRent(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono tabular-nums text-slate-200 focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Security Deposit ($)</label>
                <input
                  type="number"
                  value={securityDeposit}
                  onChange={e => setSecurityDeposit(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono tabular-nums text-slate-200 focus:outline-hidden focus:border-blue-500"
                />
              </div>
            </div>

            {currentUnit && (
              <p className="text-[11px] text-slate-400">
                Selected: Building {currentUnit.building} · Floor {currentUnit.floor} · {currentUnit.sqft} sqft · Market Rent: ${currentUnit.marketRent.toLocaleString()}
              </p>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-800 flex items-center justify-between bg-slate-900/50">
          <button
            type="button"
            onClick={handleDeny}
            className="px-3 py-2 text-xs font-medium text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Ban className="w-3.5 h-3.5" />
            Adverse Action / Deny
          </button>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={handleSendLeasePacket}
              className="px-3.5 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5" />
              Send DocuSign Packet
            </button>

            <button
              type="button"
              onClick={handleExecuteLease}
              disabled={!selectedUnitId || isExecuting}
              className="px-4 py-2 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-sm transition-colors flex items-center gap-1.5 whitespace-nowrap"
            >
              <UserCheck className="w-3.5 h-3.5" />
              {isExecuting ? 'Executing Lease...' : 'Execute Lease & Move In'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
