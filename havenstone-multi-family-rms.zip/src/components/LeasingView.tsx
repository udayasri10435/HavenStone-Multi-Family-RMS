import React, { useState } from 'react';
import { useProperty } from '../context/PropertyContext';
import { Prospect, Lease, ProspectStage } from '../types/property';
import { 
  Users, 
  FileText, 
  Clock, 
  Search, 
  Plus, 
  Download, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  Filter,
  DollarSign,
  Send,
  CalendarCheck
} from 'lucide-react';
import { ApplicantReviewModal } from './Modals/ApplicantReviewModal';
import { NoticeToVacateModal } from './Modals/NoticeToVacateModal';

export const LeasingView: React.FC = () => {
  const { 
    filteredProspects, 
    filteredUnits, 
    filteredLeases, 
    sendRenewalOffer, 
    acceptRenewalOffer,
    advanceProspectStage
  } = useProperty();

  const [activeSubTab, setActiveSubTab] = useState<'pipeline' | 'rent_roll' | 'renewals'>('pipeline');
  const [pipelineFilter, setPipelineFilter] = useState<string>('all');
  const [rentRollStatusFilter, setRentRollStatusFilter] = useState<string>('all');
  
  // Modals state
  const [selectedProspect, setSelectedProspect] = useState<Prospect | null>(null);
  const [isNoticeModalOpen, setIsNoticeModalOpen] = useState(false);
  const [noticeDefaultUnit, setNoticeDefaultUnit] = useState<string>('');

  // Renewal bump state
  const [renewalBumps, setRenewalBumps] = useState<Record<string, number>>({});

  const stages: { stage: ProspectStage; label: string }[] = [
    { stage: 'New Lead', label: 'New Inquiries' },
    { stage: 'Tour Scheduled', label: 'Tours Booked' },
    { stage: 'Application Submitted', label: 'Apps Submitted' },
    { stage: 'Screening Review', label: 'Underwriting' },
    { stage: 'Approved', label: 'Approved' },
    { stage: 'Lease Sent', label: 'DocuSign Out' },
    { stage: 'Signed & Deposit Paid', label: 'Executed' }
  ];

  const handleExportCSV = () => {
    const headers = ['Unit', 'Floor Plan', 'Status', 'Resident', 'Actual Rent', 'Market Rent', 'Balance Due', 'Lease End'];
    const rows = filteredUnits.map(u => [
      u.unitNumber,
      `"${u.floorPlan}"`,
      u.status,
      `"${u.currentResidentName || ''}"`,
      u.actualRent,
      u.marketRent,
      u.balanceDue,
      u.leaseEndDate || ''
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `HavenStone_Rent_Roll_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSendRenewal = (leaseId: string, currentRent: number) => {
    const bump = renewalBumps[leaseId] || Math.round(currentRent * 1.04);
    sendRenewalOffer(leaseId, bump);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* View Header & Subtabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Leasing & Resident Operations</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage applicant underwriting, live certified rent roll, and lease renewal retention
          </p>
        </div>

        {/* Subtabs Segmented Bar */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg self-start sm:self-auto">
          <button
            onClick={() => setActiveSubTab('pipeline')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeSubTab === 'pipeline'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Applicant Pipeline ({filteredProspects.length})
          </button>
          <button
            onClick={() => setActiveSubTab('rent_roll')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeSubTab === 'rent_roll'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Certified Rent Roll ({filteredUnits.length})
          </button>
          <button
            onClick={() => setActiveSubTab('renewals')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeSubTab === 'renewals'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Lease Expirations ({filteredLeases.length})
          </button>
        </div>
      </div>

      {/* SUBTAB 1: APPLICANT PIPELINE / CRM */}
      {activeSubTab === 'pipeline' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">Filter by Stage:</span>
              <select
                value={pipelineFilter}
                onChange={e => setPipelineFilter(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-hidden focus:border-blue-500"
              >
                <option value="all">All Stages</option>
                {stages.map(s => (
                  <option key={s.stage} value={s.stage}>{s.label}</option>
                ))}
              </select>
            </div>
            <span className="text-xs text-slate-500">
              Click an applicant to review credit, verify income, or execute lease
            </span>
          </div>

          {/* Pipeline Kanban Columns */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {stages
              .filter(s => pipelineFilter === 'all' || pipelineFilter === s.stage)
              .map(col => {
                const applicants = filteredProspects.filter(p => p.stage === col.stage);
                return (
                  <div key={col.stage} className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3 space-y-3 flex flex-col">
                    <div className="flex items-center justify-between border-b border-slate-800/60 pb-2">
                      <span className="text-xs font-semibold text-slate-200">{col.label}</span>
                      <span className="text-[11px] font-mono text-slate-400 px-1.5 py-0.5 rounded-md bg-slate-950">
                        {applicants.length}
                      </span>
                    </div>

                    <div className="space-y-2.5 flex-1 min-h-[140px]">
                      {applicants.length === 0 ? (
                        <div className="h-full flex items-center justify-center p-4 text-center text-xs text-slate-600 italic">
                          No applicants in this stage
                        </div>
                      ) : (
                        applicants.map(p => (
                          <div
                            key={p.id}
                            onClick={() => setSelectedProspect(p)}
                            className="bg-slate-950/90 border border-slate-800 hover:border-blue-500/60 rounded-lg p-3 cursor-pointer transition-all hover:shadow-md space-y-2 group"
                          >
                            <div className="flex items-start justify-between">
                              <div>
                                <h4 className="text-xs font-semibold text-slate-100 group-hover:text-blue-400 transition-colors">
                                  {p.applicantName}
                                </h4>
                                <span className="text-[11px] text-slate-400 block">
                                  {p.desiredFloorPlan} {p.assignedUnitNumber ? `· Unit ${p.assignedUnitNumber}` : ''}
                                </span>
                              </div>
                              <span className="text-[11px] font-mono text-emerald-400 font-medium">
                                {p.creditScore} CS
                              </span>
                            </div>

                            <div className="text-[11px] text-slate-400 flex items-center justify-between border-t border-slate-800/60 pt-2 font-mono tabular-nums">
                              <span>${p.monthlyIncome.toLocaleString()}/mo</span>
                              <span className="text-slate-300 font-semibold">{p.incomeToRentRatio}x Rent</span>
                            </div>

                            <div className="text-[10px] text-slate-500 flex items-center justify-between">
                              <span>Move-in: {p.desiredMoveIn}</span>
                              <span className="text-blue-400 flex items-center gap-0.5">
                                Review <ArrowRight className="w-2.5 h-2.5" />
                              </span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* SUBTAB 2: CERTIFIED RENT ROLL */}
      {activeSubTab === 'rent_roll' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Unit Status:</span>
                <select
                  value={rentRollStatusFilter}
                  onChange={e => setRentRollStatusFilter(e.target.value)}
                  className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-hidden focus:border-blue-500"
                >
                  <option value="all">All Units</option>
                  <option value="Occupied">Occupied</option>
                  <option value="Notice Given">Notice Given</option>
                  <option value="Vacant Ready">Vacant Ready</option>
                  <option value="Vacant Unready">Vacant Unready</option>
                  <option value="Model">Model / Office</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 text-xs font-medium bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-200 rounded-lg transition-colors flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Download className="w-3.5 h-3.5" />
              Export Rent Roll CSV
            </button>
          </div>

          {/* High Density Rent Roll Table */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/70 text-slate-400 font-mono uppercase tracking-wider text-[10px]">
                    <th className="py-2.5 px-3">Unit</th>
                    <th className="py-2.5 px-3">Floor Plan</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Resident</th>
                    <th className="py-2.5 px-3 text-right">In-Place Rent</th>
                    <th className="py-2.5 px-3 text-right">Market Rent</th>
                    <th className="py-2.5 px-3 text-right">Variance</th>
                    <th className="py-2.5 px-3">Lease Dates</th>
                    <th className="py-2.5 px-3 text-right">Balance Due</th>
                    <th className="py-2.5 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {filteredUnits
                    .filter(u => rentRollStatusFilter === 'all' || u.status === rentRollStatusFilter)
                    .map(u => {
                      const variance = u.actualRent > 0 ? u.actualRent - u.marketRent : 0;
                      return (
                        <tr key={u.id} className="hover:bg-slate-850/50 transition-colors">
                          <td className="py-2.5 px-3 font-mono font-semibold text-slate-100">
                            {u.unitNumber}
                          </td>
                          <td className="py-2.5 px-3 text-slate-300">
                            {u.floorPlan} <span className="text-slate-500 font-mono">({u.sqft} sqft)</span>
                          </td>
                          <td className="py-2.5 px-3">
                            <span className={`text-[11px] font-medium ${
                              u.status === 'Occupied' ? 'text-emerald-400' :
                              u.status === 'Notice Given' ? 'text-amber-400' :
                              u.status === 'Vacant Ready' ? 'text-blue-400' :
                              'text-slate-400'
                            }`}>
                              {u.status}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-slate-200">
                            {u.currentResidentName || <span className="text-slate-600 italic">Vacant</span>}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-100 font-semibold">
                            {u.actualRent > 0 ? `$${u.actualRent.toLocaleString()}` : '—'}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-400">
                            ${u.marketRent.toLocaleString()}
                          </td>
                          <td className={`py-2.5 px-3 text-right font-mono tabular-nums text-[11px] ${
                            variance > 0 ? 'text-emerald-400' : variance < 0 ? 'text-rose-400' : 'text-slate-500'
                          }`}>
                            {variance > 0 ? `+$${variance}` : variance < 0 ? `-$${Math.abs(variance)}` : '$0'}
                          </td>
                          <td className="py-2.5 px-3 text-[11px] text-slate-400 font-mono tabular-nums">
                            {u.leaseEndDate ? `Ends ${u.leaseEndDate}` : '—'}
                          </td>
                          <td className={`py-2.5 px-3 text-right font-mono tabular-nums font-semibold ${
                            u.balanceDue > 0 ? 'text-rose-400' : 'text-slate-500'
                          }`}>
                            {u.balanceDue > 0 ? `$${u.balanceDue.toLocaleString()}` : '$0'}
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            {u.status === 'Occupied' && (
                              <button
                                onClick={() => {
                                  setNoticeDefaultUnit(u.unitNumber);
                                  setIsNoticeModalOpen(true);
                                }}
                                className="text-[11px] text-slate-400 hover:text-amber-400 hover:underline transition-colors"
                              >
                                Log Notice
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 3: LEASE EXPIRATIONS & RENEWALS */}
      {activeSubTab === 'renewals' && (
        <div className="space-y-4">
          <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Automated Renewal Strategy</h3>
              <p className="text-xs text-slate-400">
                Recommended rent adjustment (+3.8% market benchmark based on regional submarket rent index)
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-mono">
                {filteredLeases.filter(l => l.daysToExpiration <= 60).length} Leases Expiring in 60 Days
              </span>
            </div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/70 text-slate-400 font-mono uppercase tracking-wider text-[10px]">
                    <th className="py-2.5 px-3">Unit</th>
                    <th className="py-2.5 px-3">Resident</th>
                    <th className="py-2.5 px-3">Current Rent</th>
                    <th className="py-2.5 px-3">Expiration</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Proposed Renewal</th>
                    <th className="py-2.5 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {filteredLeases.map(l => {
                    const defaultBump = Math.round(l.monthlyRent * 1.04);
                    const currentBump = renewalBumps[l.id] || (l.proposedRenewalRent || defaultBump);

                    return (
                      <tr key={l.id} className="hover:bg-slate-850/50 transition-colors">
                        <td className="py-3 px-3 font-mono font-semibold text-slate-100">
                          {l.unitNumber}
                        </td>
                        <td className="py-3 px-3 text-slate-200">
                          <div className="font-medium">{l.residentName}</div>
                          <div className="text-[11px] text-slate-500 font-mono">{l.email}</div>
                        </td>
                        <td className="py-3 px-3 font-mono tabular-nums text-slate-200">
                          ${l.monthlyRent.toLocaleString()}/mo
                        </td>
                        <td className="py-3 px-3 font-mono tabular-nums">
                          <span className={`text-xs ${l.daysToExpiration <= 30 ? 'text-amber-400 font-semibold' : 'text-slate-300'}`}>
                            {l.leaseEndDate} ({l.daysToExpiration}d)
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <span className={`text-[11px] ${
                            l.leaseStatus === 'Renewal Pending' ? 'text-blue-400' :
                            l.leaseStatus === 'Notice to Vacate' ? 'text-amber-400' :
                            'text-emerald-400'
                          }`}>
                            {l.leaseStatus}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-1.5">
                            <span className="text-slate-500 text-xs">$</span>
                            <input
                              type="number"
                              value={currentBump}
                              onChange={e => setRenewalBumps({ ...renewalBumps, [l.id]: Number(e.target.value) })}
                              className="w-24 bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs font-mono tabular-nums text-slate-100 focus:outline-hidden focus:border-blue-500"
                            />
                            <span className="text-[10px] text-emerald-400 font-mono tabular-nums">
                              (+{Math.round(((currentBump - l.monthlyRent) / l.monthlyRent) * 100)}%)
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-right">
                          <div className="flex items-center justify-end gap-2">
                            {l.renewalOfferSent ? (
                              <button
                                onClick={() => acceptRenewalOffer(l.id)}
                                className="px-2.5 py-1 text-[11px] font-medium bg-emerald-600 hover:bg-emerald-500 text-white rounded-md transition-colors flex items-center gap-1"
                              >
                                <CalendarCheck className="w-3 h-3" />
                                Accept & Extend
                              </button>
                            ) : (
                              <button
                                onClick={() => handleSendRenewal(l.id, l.monthlyRent)}
                                className="px-2.5 py-1 text-[11px] font-medium bg-blue-600 hover:bg-blue-500 text-white rounded-md transition-colors flex items-center gap-1"
                              >
                                <Send className="w-3 h-3" />
                                Send Offer
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <ApplicantReviewModal
        prospect={selectedProspect}
        isOpen={!!selectedProspect}
        onClose={() => setSelectedProspect(null)}
      />

      <NoticeToVacateModal
        defaultUnitNumber={noticeDefaultUnit}
        isOpen={isNoticeModalOpen}
        onClose={() => {
          setIsNoticeModalOpen(false);
          setNoticeDefaultUnit('');
        }}
      />
    </div>
  );
};
