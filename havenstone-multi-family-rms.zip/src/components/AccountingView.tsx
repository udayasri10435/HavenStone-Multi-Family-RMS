import React, { useState } from 'react';
import { useProperty } from '../context/PropertyContext';
import { LedgerTransaction, Lease } from '../types/property';
import { 
  DollarSign, 
  FileSpreadsheet, 
  AlertTriangle, 
  TrendingUp, 
  Download, 
  Plus, 
  Printer, 
  ArrowUpRight,
  CreditCard,
  Building
} from 'lucide-react';
import { PostTransactionModal } from './Modals/PostTransactionModal';
import { Notice3DayModal } from './Modals/Notice3DayModal';

export const AccountingView: React.FC = () => {
  const { 
    filteredLedger, 
    filteredLeases, 
    currentProperty, 
    properties,
    postTransaction
  } = useProperty();

  const [activeSubTab, setActiveSubTab] = useState<'operating_statement' | 'delinquency' | 'transactions'>('operating_statement');
  const [isPostTxModalOpen, setIsPostTxModalOpen] = useState(false);
  const [selectedLeaseForNotice, setSelectedLeaseForNotice] = useState<Lease | null>(null);

  // Financial calculations
  const totalUnits = currentProperty ? currentProperty.totalUnits : properties.reduce((a, b) => a + b.totalUnits, 0);
  const avgRent = currentProperty ? currentProperty.avgMarketRent : 2250;
  
  const grossPotentialRent = totalUnits * avgRent;
  const vacancyLoss = Math.round(grossPotentialRent * (1 - (currentProperty ? currentProperty.physicalOccupancy / 100 : 0.95)));
  const concessions = Math.round(grossPotentialRent * 0.012);
  const netRentalIncome = grossPotentialRent - vacancyLoss - concessions;

  const rubsIncome = Math.round(totalUnits * 72);
  const parkingIncome = Math.round(totalUnits * 65);
  const petIncome = Math.round(totalUnits * 18);
  const feeIncome = 4500;
  const totalOtherIncome = rubsIncome + parkingIncome + petIncome + feeIncome;

  const effectiveGrossIncome = netRentalIncome + totalOtherIncome;

  // Operating Expenses
  const payrollExpense = Math.round(totalUnits * 110);
  const repairsExpense = Math.round(totalUnits * 65);
  const turnoverExpense = Math.round(totalUnits * 45);
  const utilitiesExpense = Math.round(totalUnits * 78);
  const contractServices = Math.round(totalUnits * 42);
  const managementFee = Math.round(effectiveGrossIncome * 0.03);
  const marketingExpense = Math.round(totalUnits * 25);
  const propertyTaxes = Math.round(totalUnits * 210);
  const insuranceExpense = Math.round(totalUnits * 55);

  const totalOpEx = payrollExpense + repairsExpense + turnoverExpense + utilitiesExpense + contractServices + managementFee + marketingExpense + propertyTaxes + insuranceExpense;
  const netOperatingIncome = effectiveGrossIncome - totalOpEx;
  const opexRatio = Math.round((totalOpEx / effectiveGrossIncome) * 1000) / 10;

  // Delinquency calculations
  const delinquentLeases = filteredLeases.filter(l => l.balanceDue > 0);
  const totalDelinquency = delinquentLeases.reduce((acc, l) => acc + l.balanceDue, 0);

  const handleExportJournalCSV = () => {
    const headers = ['TX ID', 'Date', 'Unit', 'Resident', 'Category', 'Type', 'Method', 'Amount', 'Ref No'];
    const rows = filteredLedger.map(tx => [
      tx.id,
      tx.date,
      tx.unitNumber,
      `"${tx.residentName}"`,
      tx.category,
      tx.type,
      tx.method || '',
      tx.amount,
      tx.referenceNo
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `HavenStone_General_Ledger_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* View Header & Subtabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">General Ledger & Financial Accounting</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Institutional monthly operating statement (T-12), accounts receivable delinquency, and ledger journal
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Subtabs Bar */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg self-start sm:self-auto">
            <button
              onClick={() => setActiveSubTab('operating_statement')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeSubTab === 'operating_statement'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Operating P&L (T-12)
            </button>
            <button
              onClick={() => setActiveSubTab('delinquency')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeSubTab === 'delinquency'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Delinquency Aging ({delinquentLeases.length})
            </button>
            <button
              onClick={() => setActiveSubTab('transactions')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeSubTab === 'transactions'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Transaction Journal ({filteredLedger.length})
            </button>
          </div>

          <button
            onClick={() => setIsPostTxModalOpen(true)}
            className="px-3 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Post Transaction</span>
          </button>
        </div>
      </div>

      {/* SUBTAB 1: OPERATING STATEMENT (P&L / NOI) */}
      {activeSubTab === 'operating_statement' && (
        <div className="space-y-6">
          {/* Top Financial Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 space-y-1">
              <span className="text-xs text-slate-400">Effective Gross Income (Monthly)</span>
              <div className="text-2xl font-bold font-mono tabular-nums text-white">
                ${effectiveGrossIncome.toLocaleString()}
              </div>
              <span className="text-[11px] text-slate-500 font-mono">
                ${(effectiveGrossIncome * 12).toLocaleString()}/yr annualized
              </span>
            </div>

            <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 space-y-1">
              <span className="text-xs text-slate-400">Total Operating Expenses (OpEx)</span>
              <div className="text-2xl font-bold font-mono tabular-nums text-slate-200">
                ${totalOpEx.toLocaleString()}
              </div>
              <span className="text-[11px] text-emerald-400 font-mono">
                {opexRatio}% Expense Ratio (Target &lt; 42%)
              </span>
            </div>

            <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 space-y-1">
              <span className="text-xs text-slate-400">Net Operating Income (NOI)</span>
              <div className="text-2xl font-bold font-mono tabular-nums text-emerald-400">
                ${netOperatingIncome.toLocaleString()}
              </div>
              <span className="text-[11px] text-slate-500 font-mono">
                ${(netOperatingIncome * 12).toLocaleString()}/yr net cashflow
              </span>
            </div>
          </div>

          {/* Institutional Operating Statement Breakdown */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-xs">
            <div className="px-6 py-4 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white">
                  Monthly Operating Statement · GAAP Multi-Family Chart of Accounts
                </h3>
                <p className="text-xs text-slate-400">
                  {currentProperty ? currentProperty.name : 'Portfolio Summary'} · {totalUnits} Total Units
                </p>
              </div>
              <span className="text-xs font-mono text-slate-400">USD ($) Currency</span>
            </div>

            <div className="p-6 space-y-6 text-xs">
              {/* REVENUE SECTION */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider pb-1 border-b border-slate-800">
                  I. Rental Revenue & Deductions
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">5100 · Gross Potential Rent (GPR)</span>
                  <span className="font-mono tabular-nums text-slate-200">${grossPotentialRent.toLocaleString()}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">5200 · Economic Vacancy Loss</span>
                  <span className="font-mono tabular-nums text-rose-400">-${vacancyLoss.toLocaleString()}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">5250 · Resident Concessions & Bad Debt</span>
                  <span className="font-mono tabular-nums text-rose-400">-${concessions.toLocaleString()}</span>
                </div>
                <div className="flex justify-between py-1 font-semibold text-slate-100 bg-slate-950/40 px-2 rounded">
                  <span>Net Rental Revenue</span>
                  <span className="font-mono tabular-nums text-emerald-400">${netRentalIncome.toLocaleString()}</span>
                </div>
              </div>

              {/* OTHER INCOME */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider pb-1 border-b border-slate-800">
                  II. Ancillary & Other Income
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">5300 · RUBS Utility Reimbursement (Water/Sewer/Trash)</span>
                  <span className="font-mono tabular-nums text-slate-200">${rubsIncome.toLocaleString()}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">5320 · Reserved Parking & Carport Fees</span>
                  <span className="font-mono tabular-nums text-slate-200">${parkingIncome.toLocaleString()}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">5340 · Monthly Pet Rent & Animal Administration</span>
                  <span className="font-mono tabular-nums text-slate-200">${petIncome.toLocaleString()}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">5360 · Late Fees, Application & NSF Fees</span>
                  <span className="font-mono tabular-nums text-slate-200">${feeIncome.toLocaleString()}</span>
                </div>
                <div className="flex justify-between py-1 font-semibold text-slate-100 bg-slate-950/40 px-2 rounded">
                  <span>Effective Gross Income (EGI)</span>
                  <span className="font-mono tabular-nums text-emerald-400">${effectiveGrossIncome.toLocaleString()}</span>
                </div>
              </div>

              {/* OPERATING EXPENSES */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider pb-1 border-b border-slate-800">
                  III. Controllable & Non-Controllable Operating Expenses (OpEx)
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1">
                  <div className="flex justify-between py-1 border-b border-slate-850">
                    <span className="text-slate-400">6100 · Onsite Staff Payroll & Benefits</span>
                    <span className="font-mono tabular-nums text-slate-200">${payrollExpense.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-850">
                    <span className="text-slate-400">6200 · Repairs & Routine Maintenance</span>
                    <span className="font-mono tabular-nums text-slate-200">${repairsExpense.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-850">
                    <span className="text-slate-400">6250 · Unit Turnover & Make-Ready Materials</span>
                    <span className="font-mono tabular-nums text-slate-200">${turnoverExpense.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-850">
                    <span className="text-slate-400">6300 · Utilities (Electric, Water & Sewer)</span>
                    <span className="font-mono tabular-nums text-slate-200">${utilitiesExpense.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-850">
                    <span className="text-slate-400">6400 · Contract Services (HVAC, Elevators, Pest)</span>
                    <span className="font-mono tabular-nums text-slate-200">${contractServices.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-850">
                    <span className="text-slate-400">6500 · Management Fee (3.0% EGI)</span>
                    <span className="font-mono tabular-nums text-slate-200">${managementFee.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-850">
                    <span className="text-slate-400">6600 · Marketing & Digital Advertising</span>
                    <span className="font-mono tabular-nums text-slate-200">${marketingExpense.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-850">
                    <span className="text-slate-400">6700 · Real Estate Property Taxes</span>
                    <span className="font-mono tabular-nums text-slate-200">${propertyTaxes.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-850">
                    <span className="text-slate-400">6800 · Property & Casualty Insurance</span>
                    <span className="font-mono tabular-nums text-slate-200">${insuranceExpense.toLocaleString()}</span>
                  </div>
                </div>
                <div className="flex justify-between py-1.5 font-semibold text-slate-100 bg-slate-950/40 px-2 rounded mt-2">
                  <span>Total Operating Expenses</span>
                  <span className="font-mono tabular-nums text-slate-200">${totalOpEx.toLocaleString()}</span>
                </div>
              </div>

              {/* BOTTOM LINE NOI */}
              <div className="p-4 bg-emerald-950/20 border border-emerald-900/40 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-xs uppercase tracking-wider text-emerald-400 font-semibold block">
                    NET OPERATING INCOME (NOI)
                  </span>
                  <span className="text-xs text-slate-400">Before Debt Service & Capital Replacements</span>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                    ${netOperatingIncome.toLocaleString()}
                  </span>
                  <span className="text-xs text-slate-400 block font-mono">
                    ${(netOperatingIncome * 12).toLocaleString()}/yr run rate
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: DELINQUENCY AGING & COLLECTIONS */}
      {activeSubTab === 'delinquency' && (
        <div className="space-y-4">
          <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Accounts Receivable Delinquency Aging</h3>
              <p className="text-xs text-slate-400">
                Track overdue resident ledger balances and trigger statutory 3-day notice to pay or quit.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-rose-400 font-semibold">
                ${totalDelinquency.toLocaleString()} Total Outstanding Delinquency
              </span>
            </div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/70 text-slate-400 font-mono uppercase tracking-wider text-[10px]">
                  <th className="py-2.5 px-3">Unit</th>
                  <th className="py-2.5 px-3">Resident</th>
                  <th className="py-2.5 px-3">Monthly Rent</th>
                  <th className="py-2.5 px-3 text-right">Balance Due</th>
                  <th className="py-2.5 px-3">Aging Status</th>
                  <th className="py-2.5 px-3">Last Payment</th>
                  <th className="py-2.5 px-3 text-right">Statutory Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                {delinquentLeases.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-slate-500 italic">
                      Zero delinquent accounts! 100% current on rent collections.
                    </td>
                  </tr>
                ) : (
                  delinquentLeases.map(l => (
                    <tr key={l.id} className="hover:bg-slate-850/50">
                      <td className="py-3 px-3 font-mono font-semibold text-slate-100">
                        Unit {l.unitNumber}
                      </td>
                      <td className="py-3 px-3 text-slate-200">
                        <div className="font-medium">{l.residentName}</div>
                        <div className="text-[11px] text-slate-500 font-mono">{l.phone}</div>
                      </td>
                      <td className="py-3 px-3 font-mono tabular-nums text-slate-300">
                        ${l.monthlyRent.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-rose-400">
                        ${l.balanceDue.toLocaleString()}.00
                      </td>
                      <td className="py-3 px-3">
                        <span className="text-[11px] font-medium text-amber-400">
                          {l.paymentStatus}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-400 text-[11px] font-mono">
                        Aug 28, 2026 (Cleared)
                      </td>
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={() => setSelectedLeaseForNotice(l)}
                          className="px-2.5 py-1 text-[11px] font-medium bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 rounded-md transition-colors"
                        >
                          Generate 3-Day Notice
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUBTAB 3: TRANSACTION JOURNAL */}
      {activeSubTab === 'transactions' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">
              Showing {filteredLedger.length} posted transactions
            </span>
            <button
              onClick={handleExportJournalCSV}
              className="px-3 py-1.5 text-xs font-medium bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              Export Journal CSV
            </button>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/70 text-slate-400 font-mono uppercase tracking-wider text-[10px]">
                  <th className="py-2.5 px-3">Tx Ref</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Unit</th>
                  <th className="py-2.5 px-3">Resident</th>
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3">Method</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                {filteredLedger.map(tx => (
                  <tr key={tx.id} className="hover:bg-slate-850/50">
                    <td className="py-2.5 px-3 font-mono text-slate-300">
                      {tx.referenceNo}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-400 text-[11px]">
                      {tx.date}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-200 font-semibold">
                      {tx.unitNumber}
                    </td>
                    <td className="py-2.5 px-3 text-slate-200">
                      {tx.residentName}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      {tx.category}
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                      {tx.method || 'System Ledger'}
                    </td>
                    <td className={`py-2.5 px-3 text-right font-mono tabular-nums font-semibold ${
                      tx.type === 'Payment' ? 'text-emerald-400' : 'text-slate-200'
                    }`}>
                      {tx.type === 'Payment' ? `+$${tx.amount.toLocaleString()}` : `-$${tx.amount.toLocaleString()}`}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="text-[11px] text-emerald-400 font-medium">
                        {tx.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modals */}
      <PostTransactionModal
        isOpen={isPostTxModalOpen}
        onClose={() => setIsPostTxModalOpen(false)}
      />

      <Notice3DayModal
        lease={selectedLeaseForNotice}
        property={currentProperty}
        isOpen={!!selectedLeaseForNotice}
        onClose={() => setSelectedLeaseForNotice(null)}
      />
    </div>
  );
};
