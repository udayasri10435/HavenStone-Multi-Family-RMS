import React from 'react';
import { PropertyProvider, useProperty } from './context/PropertyContext';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { LeasingView } from './components/LeasingView';
import { MaintenanceView } from './components/MaintenanceView';
import { AccountingView } from './components/AccountingView';
import { UnitsInventoryView } from './components/UnitsInventoryView';
import { ResidentPortalView } from './components/ResidentPortalView';

const MainContent: React.FC = () => {
  const { activeTab } = useProperty();

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
      {activeTab === 'dashboard' && <DashboardView />}
      {activeTab === 'leasing' && <LeasingView />}
      {activeTab === 'maintenance' && <MaintenanceView />}
      {activeTab === 'accounting' && <AccountingView />}
      {activeTab === 'units' && <UnitsInventoryView />}
      {activeTab === 'resident_portal' && <ResidentPortalView />}
    </main>
  );
};

export default function App() {
  return (
    <PropertyProvider>
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
        <Header />
        
        <div className="flex-1">
          <MainContent />
        </div>

        {/* Quiet Institutional Footer */}
        <footer className="border-t border-slate-900 bg-slate-950 py-6 text-xs text-slate-500">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-400">HavenStone RMS</span>
              <span>·</span>
              <span>Institutional Multi-Family Property Operating System</span>
            </div>
            <div className="flex items-center gap-4 text-slate-400">
              <span>Yardi & AppFolio Compliant Schema</span>
              <span>·</span>
              <span>NACHA ACH & Plaid Ready</span>
              <span>·</span>
              <span>Equal Housing Opportunity</span>
            </div>
          </div>
        </footer>
      </div>
    </PropertyProvider>
  );
}
