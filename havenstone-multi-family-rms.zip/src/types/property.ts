export type UserRole = 'property_manager' | 'leasing_agent' | 'maintenance_supervisor' | 'resident_portal';

export type UnitStatus = 
  | 'Occupied' 
  | 'Notice Given' 
  | 'Vacant Ready' 
  | 'Vacant Unready' 
  | 'Model' 
  | 'Down / Offline';

export interface Property {
  id: string;
  name: string;
  code: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  totalUnits: number;
  occupiedUnits: number;
  vacantUnits: number;
  yearBuilt: number;
  assetClass: 'Class A' | 'Class B+' | 'Class B';
  avgMarketRent: number;
  physicalOccupancy: number; // e.g. 95.8
  economicOccupancy: number; // e.g. 93.2
  delinquencyRate: number; // e.g. 1.4
  noiYTD: number;
  accentColor: string;
}

export interface Unit {
  id: string;
  propertyId: string;
  unitNumber: string;
  building: string;
  floor: number;
  floorPlan: string; // e.g. 'A1 - 1 Bed / 1 Bath', 'B2 - 2 Bed / 2 Bath'
  bedrooms: number;
  bathrooms: number;
  sqft: number;
  marketRent: number;
  actualRent: number;
  status: UnitStatus;
  currentResidentId?: string;
  currentResidentName?: string;
  leaseStartDate?: string;
  leaseEndDate?: string;
  depositHeld: number;
  balanceDue: number;
  isReadyForMoveIn: boolean;
  renovationTag?: string;
}

export type ProspectStage = 
  | 'New Lead' 
  | 'Tour Scheduled' 
  | 'Application Submitted' 
  | 'Screening Review' 
  | 'Approved' 
  | 'Lease Sent' 
  | 'Signed & Deposit Paid' 
  | 'Denied';

export interface Prospect {
  id: string;
  propertyId: string;
  applicantName: string;
  email: string;
  phone: string;
  desiredMoveIn: string;
  desiredFloorPlan: string;
  assignedUnitId?: string;
  assignedUnitNumber?: string;
  stage: ProspectStage;
  creditScore: number;
  annualIncome: number;
  monthlyIncome: number;
  incomeToRentRatio: number;
  backgroundStatus: 'Clear' | 'Conditional' | 'Adverse';
  coSigner: boolean;
  applicationFeePaid: boolean;
  depositStatus: 'Unpaid' | 'Paid' | 'Waived';
  applicationDate: string;
  notes: string;
}

export interface Lease {
  id: string;
  propertyId: string;
  unitId: string;
  unitNumber: string;
  residentName: string;
  email: string;
  phone: string;
  leaseStartDate: string;
  leaseEndDate: string;
  monthlyRent: number;
  securityDeposit: number;
  petRent: number;
  parkingFee: number;
  rubsFee: number; // Ratio Utility Billing System
  balanceDue: number;
  autopayEnabled: boolean;
  paymentStatus: 'Current' | 'Late (3-Day Notice)' | 'Grace Period' | 'Delinquent';
  leaseStatus: 'Active' | 'Notice to Vacate' | 'Renewal Pending' | 'Month-to-Month';
  daysToExpiration: number;
  renewalOfferSent?: boolean;
  proposedRenewalRent?: number;
  insuranceVerified: boolean;
  emergencyContact: string;
}

export type MaintenancePriority = 'Emergency (4h)' | 'High (24h)' | 'Routine (72h)';
export type MaintenanceStatus = 'Submitted' | 'Dispatched' | 'In Progress' | 'Awaiting Parts' | 'Completed';
export type MaintenanceCategory = 'HVAC' | 'Plumbing' | 'Electrical' | 'Appliance' | 'Carpentry' | 'Locks / Access' | 'General';

export interface WorkOrder {
  id: string;
  propertyId: string;
  unitNumber: string;
  residentName: string;
  category: MaintenanceCategory;
  priority: MaintenancePriority;
  status: MaintenanceStatus;
  title: string;
  description: string;
  entryPermission: boolean;
  assignedTech: string;
  createdAt: string;
  updatedAt: string;
  targetCompletion: string;
  laborHours: number;
  partsCost: number;
  notes: string[];
  residentRating?: number;
}

export interface TurnStep {
  name: string;
  completed: boolean;
  vendorOrTech?: string;
  cost?: number;
}

export interface MakeReadyTurn {
  id: string;
  propertyId: string;
  unitNumber: string;
  moveOutDate: string;
  targetMoveInDate: string;
  status: 'In Progress' | 'Inspection Passed' | 'Delayed';
  leadTech: string;
  budgetAllocated: number;
  actualCost: number;
  steps: TurnStep[];
  notes: string;
}

export interface LedgerTransaction {
  id: string;
  propertyId: string;
  unitNumber: string;
  residentName: string;
  date: string;
  category: 'Rent' | 'Late Fee' | 'RUBS Utility' | 'Parking' | 'Pet Fee' | 'Security Deposit' | 'Work Order Charge' | 'Concession';
  amount: number;
  type: 'Charge' | 'Payment' | 'Credit';
  method?: 'ACH Direct' | 'Credit Card' | 'Check / Money Order' | 'System Credit';
  status: 'Cleared' | 'Pending' | 'Reversed';
  referenceNo: string;
}

export interface PackageDelivery {
  id: string;
  trackingLast4: string;
  carrier: 'Amazon' | 'UPS' | 'FedEx' | 'USPS';
  lockerNumber: string;
  pickupCode: string;
  deliveredAt: string;
  pickedUp: boolean;
}

export interface AmenityReservation {
  id: string;
  amenityName: string;
  date: string;
  timeSlot: string;
  status: 'Confirmed' | 'Pending Review' | 'Cancelled';
}
